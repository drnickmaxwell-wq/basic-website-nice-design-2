var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/heygen/avatar-video/route.js")
R.c("server/chunks/[root-of-the-server]__c7dcca5d._.js")
R.c("server/chunks/node_modules_next_317e10ab._.js")
R.m(32672)
R.m(34243)
module.exports=R.m(34243).exports
