var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/heygen/status/[videoId]/route.js")
R.c("server/chunks/[root-of-the-server]__98d91488._.js")
R.c("server/chunks/node_modules_next_317e10ab._.js")
R.m(69335)
R.m(4808)
module.exports=R.m(4808).exports
