var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/chatbot/route.js")
R.c("server/chunks/[root-of-the-server]__2fdbc2c9._.js")
R.c("server/chunks/node_modules_next_317e10ab._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_85986aea.js")
R.m(54424)
R.m(17950)
module.exports=R.m(17950).exports
