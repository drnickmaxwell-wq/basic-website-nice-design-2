var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/synthesia/generate-video/route.js")
R.c("server/chunks/[root-of-the-server]__eea4e8ee._.js")
R.c("server/chunks/node_modules_next_317e10ab._.js")
R.m(39230)
R.m(29350)
module.exports=R.m(29350).exports
