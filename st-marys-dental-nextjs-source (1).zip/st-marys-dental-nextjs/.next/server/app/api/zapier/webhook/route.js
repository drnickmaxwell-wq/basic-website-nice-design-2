var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/zapier/webhook/route.js")
R.c("server/chunks/[root-of-the-server]__705dedd0._.js")
R.c("server/chunks/node_modules_next_317e10ab._.js")
R.m(26898)
R.m(16928)
module.exports=R.m(16928).exports
