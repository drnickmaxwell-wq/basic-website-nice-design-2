var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/appointments/book/route.js")
R.c("server/chunks/[root-of-the-server]__ecbd048d._.js")
R.c("server/chunks/node_modules_next_317e10ab._.js")
R.m(80383)
R.m(38998)
module.exports=R.m(38998).exports
