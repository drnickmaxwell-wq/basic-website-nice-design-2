__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/e3215948f384d7fd.js",
  "static/chunks/turbopack-2451de724a6a0f22.js"
])
