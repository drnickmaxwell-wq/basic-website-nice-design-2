'use client';
import React, { useState } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { ChevronRight, BookOpen, FileText, Eye, Clock, CheckCircle, ArrowRight, Info, Lightbulb, Heart, Shield } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function TreatmentInformationPage() {
  const [activeTab, setActiveTab] = useState('overview');

  const treatmentCategories = [
    {
      id: 'cosmetic',
      title: 'Cosmetic Dentistry',
      description: 'Enhance your smile with our advanced cosmetic treatments',
      icon: '✨',
      color: 'bg-st-turquoise',
      treatments: ['Spark Aligners', '3D Printed Veneers', 'Teeth Whitening']
    },
    {
      id: 'restorative',
      title: 'Restorative Dentistry',
      description: 'Restore function and beauty to damaged teeth',
      icon: '🦷',
      color: 'bg-st-magenta',
      treatments: ['Surgically-Guided Implants', 'Crowns & Bridges', 'Fillings']
    },
    {
      id: 'preventive',
      title: 'Preventive Care',
      description: 'Maintain optimal oral health with regular care',
      icon: '🛡️',
      color: 'bg-st-gold',
      treatments: ['Regular Checkups', 'Professional Cleaning', 'Fluoride Treatments']
    },
    {
      id: 'comfort',
      title: 'Comfort Dentistry',
      description: 'Experience pain-free dental care',
      icon: '😌',
      color: 'bg-st-turquoise',
      treatments: ['The Wand System', 'Sedation Dentistry', 'Relaxation Techniques']
    }
  ];

  const stepByStepGuides = [
    {
      title: 'Your First Visit',
      steps: [
        { step: 1, title: 'Welcome & Registration', description: 'Complete your patient forms and meet our friendly team', duration: '15 mins' },
        { step: 2, title: 'Comprehensive Examination', description: 'Thorough assessment of your oral health and smile goals', duration: '30 mins' },
        { step: 3, title: 'Digital Imaging', description: 'Advanced 3D scans and photographs for precise treatment planning', duration: '15 mins' },
        { step: 4, title: 'Treatment Discussion', description: 'Personalized treatment options and cost estimates', duration: '20 mins' },
        { step: 5, title: 'Schedule Follow-up', description: 'Book your next appointment and receive care instructions', duration: '10 mins' }
      ]
    },
    {
      title: 'Spark Aligners Process',
      steps: [
        { step: 1, title: 'Initial Consultation', description: 'Assessment of your alignment needs and treatment goals', duration: '45 mins' },
        { step: 2, title: '3D Scanning', description: 'Precise digital impressions using advanced iTero scanner', duration: '20 mins' },
        { step: 3, title: 'Treatment Planning', description: 'Custom treatment plan with 3D visualization of results', duration: '1 week' },
        { step: 4, title: 'Aligner Fitting', description: 'Receive your first set of aligners and care instructions', duration: '30 mins' },
        { step: 5, title: 'Progress Monitoring', description: 'Regular check-ups every 6-8 weeks to track progress', duration: '6-18 months' }
      ]
    },
    {
      title: 'Dental Implant Journey',
      steps: [
        { step: 1, title: 'Comprehensive Assessment', description: 'Detailed examination and 3D imaging for implant planning', duration: '60 mins' },
        { step: 2, title: 'Surgical Planning', description: 'Precise surgical guide creation using advanced software', duration: '1-2 weeks' },
        { step: 3, title: 'Implant Placement', description: 'Minimally invasive surgery with The Wand System', duration: '60-90 mins' },
        { step: 4, title: 'Healing Period', description: 'Osseointegration process with temporary restoration', duration: '3-6 months' },
        { step: 5, title: 'Final Restoration', description: 'Custom crown placement and bite adjustment', duration: '2-3 weeks' }
      ]
    }
  ];

  const infographics = [
    {
      title: 'Oral Health Timeline',
      description: 'Understanding the importance of regular dental care throughout life',
      image: '/infographics/oral-health-timeline.png',
      category: 'preventive'
    },
    {
      title: 'Smile Transformation Process',
      description: 'Step-by-step journey from consultation to your perfect smile',
      image: '/infographics/smile-transformation.png',
      category: 'cosmetic'
    },
    {
      title: 'Implant vs. Bridge Comparison',
      description: 'Visual comparison of tooth replacement options',
      image: '/infographics/implant-vs-bridge.png',
      category: 'restorative'
    }
  ];

  return (
    <div className="container mx-auto px-4 py-12">
      <nav className="text-gray-600 mb-8" aria-label="breadcrumb">
        <ol className="list-none p-0 inline-flex">
          <li className="flex items-center">
            <Link href="/" className="hover:text-st-turquoise">Home</Link>
            <ChevronRight className="h-4 w-4 mx-2" />
          </li>
          <li className="flex items-center text-st-turquoise">
            Treatment Information
          </li>
        </ol>
      </nav>

      {/* Hero Section */}
      <section className="text-center mb-16">
        <Badge className="bg-st-turquoise text-white px-4 py-2 mb-4">
          <BookOpen className="mr-2 h-4 w-4" />
          Treatment Information
        </Badge>
        <h1 className="text-5xl lg:text-6xl font-bold text-st-dark-grey mb-6">
          Your Complete Guide to
          <span className="text-st-magenta block">Dental Treatments</span>
        </h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
          Comprehensive information about our treatments, step-by-step guides, and everything you need to know 
          about your dental care journey at St Mary's House Dental Care.
        </p>
      </section>

      {/* Treatment Categories */}
      <section className="mb-16">
        <h2 className="text-4xl font-bold text-st-dark-grey mb-8 text-center">Treatment Categories</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {treatmentCategories.map((category) => (
            <Card key={category.id} className="luxury-card group cursor-pointer hover:shadow-xl transition-all duration-300">
              <CardHeader className="text-center">
                <div className={`w-16 h-16 ${category.color} rounded-full flex items-center justify-center mx-auto mb-4 text-2xl text-white group-hover:scale-110 transition-transform duration-300`}>
                  {category.icon}
                </div>
                <CardTitle className="text-xl font-bold text-st-dark-grey group-hover:text-st-turquoise transition-colors">
                  {category.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4 text-center">{category.description}</p>
                <ul className="space-y-2">
                  {category.treatments.map((treatment, index) => (
                    <li key={index} className="flex items-center text-sm text-gray-700">
                      <CheckCircle className="h-4 w-4 text-st-turquoise mr-2" />
                      {treatment}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Interactive Tabs Section */}
      <section className="mb-16">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-8">
            <TabsTrigger value="overview" className="flex items-center">
              <Eye className="mr-2 h-4 w-4" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="guides" className="flex items-center">
              <FileText className="mr-2 h-4 w-4" />
              Step-by-Step Guides
            </TabsTrigger>
            <TabsTrigger value="infographics" className="flex items-center">
              <Lightbulb className="mr-2 h-4 w-4" />
              Infographics
            </TabsTrigger>
            <TabsTrigger value="faqs" className="flex items-center">
              <Info className="mr-2 h-4 w-4" />
              FAQs
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-8">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div>
                <h3 className="text-3xl font-bold text-st-dark-grey mb-6">Understanding Your Treatment Options</h3>
                <p className="text-lg text-gray-700 mb-6">
                  At St Mary's House Dental Care, we believe in empowering our patients with comprehensive information 
                  about their treatment options. Our approach combines advanced technology with personalized care to 
                  ensure the best possible outcomes.
                </p>
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <Heart className="h-6 w-6 text-st-magenta mt-1" />
                    <div>
                      <h4 className="font-semibold text-st-dark-grey">Patient-Centered Care</h4>
                      <p className="text-gray-600">Every treatment plan is tailored to your unique needs and goals.</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <Shield className="h-6 w-6 text-st-turquoise mt-1" />
                    <div>
                      <h4 className="font-semibold text-st-dark-grey">Advanced Technology</h4>
                      <p className="text-gray-600">State-of-the-art equipment ensures precise and comfortable treatments.</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="h-6 w-6 text-st-gold mt-1" />
                    <div>
                      <h4 className="font-semibold text-st-dark-grey">Proven Results</h4>
                      <p className="text-gray-600">Our treatments are backed by research and years of successful outcomes.</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="relative">
                <Image 
                  src="/treatment-overview.jpg" 
                  alt="Modern dental treatment room at St Mary's House Dental Care"
                  width={600}
                  height={400}
                  className="rounded-lg shadow-xl nautical-border"
                />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="guides" className="space-y-8">
            <h3 className="text-3xl font-bold text-st-dark-grey mb-6 text-center">Step-by-Step Treatment Guides</h3>
            {stepByStepGuides.map((guide, guideIndex) => (
              <Card key={guideIndex} className="luxury-card">
                <CardHeader>
                  <CardTitle className="text-2xl font-bold text-st-dark-grey flex items-center">
                    <Clock className="mr-3 h-6 w-6 text-st-turquoise" />
                    {guide.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {guide.steps.map((step, stepIndex) => (
                      <div key={stepIndex} className="flex items-start space-x-4">
                        <div className="flex-shrink-0 w-10 h-10 bg-st-turquoise text-white rounded-full flex items-center justify-center font-bold">
                          {step.step}
                        </div>
                        <div className="flex-grow">
                          <div className="flex items-center justify-between mb-2">
                            <h4 className="text-lg font-semibold text-st-dark-grey">{step.title}</h4>
                            <Badge variant="outline" className="text-st-magenta border-st-magenta">
                              {step.duration}
                            </Badge>
                          </div>
                          <p className="text-gray-600">{step.description}</p>
                        </div>
                        {stepIndex < guide.steps.length - 1 && (
                          <ArrowRight className="h-5 w-5 text-st-turquoise mt-2" />
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          <TabsContent value="infographics" className="space-y-8">
            <h3 className="text-3xl font-bold text-st-dark-grey mb-6 text-center">Visual Treatment Guides</h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {infographics.map((infographic, index) => (
                <Card key={index} className="luxury-card group cursor-pointer">
                  <div className="relative h-48 overflow-hidden rounded-t-lg">
                    <Image 
                      src={infographic.image} 
                      alt={infographic.title}
                      layout="fill"
                      objectFit="cover"
                      className="group-hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                  <CardHeader>
                    <CardTitle className="text-lg font-bold text-st-dark-grey group-hover:text-st-turquoise transition-colors">
                      {infographic.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 mb-4">{infographic.description}</p>
                    <Button variant="outline" size="sm" className="w-full">
                      View Full Infographic
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="faqs" className="space-y-8">
            <h3 className="text-3xl font-bold text-st-dark-grey mb-6 text-center">Frequently Asked Questions</h3>
            <div className="grid lg:grid-cols-2 gap-8">
              <Card className="luxury-card">
                <CardHeader>
                  <CardTitle className="text-xl font-bold text-st-dark-grey">General Treatment Questions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-st-dark-grey mb-2">How do I know which treatment is right for me?</h4>
                    <p className="text-gray-600">During your consultation, we'll assess your oral health, discuss your goals, and recommend the most suitable treatment options.</p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-st-dark-grey mb-2">Are your treatments covered by insurance?</h4>
                    <p className="text-gray-600">Coverage varies by insurance plan. We'll help you understand your benefits and provide treatment estimates.</p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-st-dark-grey mb-2">How long do treatments typically take?</h4>
                    <p className="text-gray-600">Treatment duration varies depending on complexity. We'll provide a detailed timeline during your consultation.</p>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="luxury-card">
                <CardHeader>
                  <CardTitle className="text-xl font-bold text-st-dark-grey">Comfort & Safety</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-st-dark-grey mb-2">Will my treatment be painful?</h4>
                    <p className="text-gray-600">We use The Wand System and sedation options to ensure your comfort throughout all procedures.</p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-st-dark-grey mb-2">What safety measures do you have in place?</h4>
                    <p className="text-gray-600">We follow strict sterilization protocols and use the latest safety equipment to protect our patients and staff.</p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-st-dark-grey mb-2">Can I see results before treatment?</h4>
                    <p className="text-gray-600">Yes! We use advanced 3D imaging and digital smile design to show you expected results before treatment begins.</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </section>

      {/* Call to Action */}
      <section className="text-center py-16 bg-gradient-to-r from-st-turquoise to-st-magenta rounded-lg shadow-lg">
        <h2 className="text-4xl font-bold text-white mb-4">Ready to Start Your Treatment Journey?</h2>
        <p className="text-xl text-white mb-8">Book your consultation today and let us create your personalized treatment plan.</p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button variant="gold" size="lg" className="btn-sparkle">
            Book Consultation
          </Button>
          <Button variant="outline" size="lg" className="border-white text-white hover:bg-white hover:text-st-turquoise">
            Download Treatment Guide
          </Button>
        </div>
      </section>
    </div>
  );
}

