
'use client';
import React, { useRef, useEffect, useState } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { ChevronRight, Award, GraduationCap, Briefcase, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import SkillMeter from '@/components/SkillMeter';

interface ClinicianData {
  name: string;
  role: string;
  heroVideo: string; // Path to personalized hero video
  qualifications: string[];
  experience: string;
  bio: string;
  specialties: { name: string; percentage: number; color: string }[];
  testimonials: { text: string; patient: string; rating: number }[];
  image: string;
}

// Mock data for clinicians
const cliniciansData: { [key: string]: ClinicianData } = {
  'dr-sarah-mitchell': {
    name: 'Dr. Sarah Mitchell',
    role: 'Principal Dentist & Owner',
    heroVideo: '/videos/sarah-mitchell-hero.mp4', // Placeholder video
    qualifications: ['BDS (Lon)', 'MJDF RCS (Eng)', 'MSc Aesthetic Dentistry'],
    experience: '15+ years',
    bio: 'Dr. Sarah Mitchell is the visionary behind St Mary\'s House Dental Care. With over 15 years of experience, she is renowned for her expertise in cosmetic dentistry and implantology, creating stunning, natural-looking smiles. Her passion lies in combining advanced techniques with a compassionate approach, ensuring every patient feels comfortable and confident throughout their dental journey.',
    specialties: [
      { name: 'Cosmetic Dentistry', percentage: 95, color: 'bg-st-turquoise' },
      { name: 'Dental Implants', percentage: 90, color: 'bg-st-magenta' },
      { name: 'Sedation Dentistry', percentage: 85, color: 'bg-st-gold' },
    ],
    testimonials: [
      { text: 'Dr. Mitchell gave me the smile I always dreamed of. Her attention to detail is incredible!', patient: 'Emily R.', rating: 5 },
      { text: 'I used to dread dental visits, but Dr. Mitchell\'s gentle approach changed everything.', patient: 'David S.', rating: 5 },
    ],
    image: '/flower-512.png', // Placeholder
  },
  'dr-james-thompson': {
    name: 'Dr. James Thompson',
    role: 'Associate Dentist',
    heroVideo: '/videos/james-thompson-hero.mp4', // Placeholder video
    qualifications: ['BDS (Birm)', 'PG Cert Orthodontics'],
    experience: '10+ years',
    bio: 'Dr. James Thompson is a highly skilled associate dentist with a keen interest in orthodontics and restorative dentistry. He is dedicated to providing comprehensive care, focusing on long-term oral health and beautiful smiles. Patients appreciate his calm demeanor and thorough explanations.',
    specialties: [
      { name: 'Orthodontics', percentage: 92, color: 'bg-st-turquoise' },
      { name: 'Restorative Dentistry', percentage: 88, color: 'bg-st-magenta' },
      { name: 'General Dentistry', percentage: 80, color: 'bg-st-gold' },
    ],
    testimonials: [
      { text: 'My braces journey with Dr. Thompson was smooth and the results are fantastic!', patient: 'Sarah L.', rating: 5 },
      { text: 'He made me feel at ease and explained every step of my treatment.', patient: 'Mark T.', rating: 4 },
    ],
    image: '/flower-512.png', // Placeholder
  },
  'dr-emily-chen': {
    name: 'Dr. Emily Chen',
    role: 'Associate Dentist',
    heroVideo: '/videos/emily-chen-hero.mp4', // Placeholder video
    qualifications: ['BDS (Bristol)', 'MFDS RCS (Edin)'],
    experience: '8+ years',
    bio: 'Dr. Emily Chen brings a fresh perspective and a gentle touch to our team. Specializing in periodontics and oral surgery, she is committed to providing compassionate care for patients with complex needs. Her dedication to continuous learning ensures she offers the latest and most effective treatments.',
    specialties: [
      { name: 'Periodontics', percentage: 90, color: 'bg-st-turquoise' },
      { name: 'Oral Surgery', percentage: 85, color: 'bg-st-magenta' },
      { name: 'Preventive Care', percentage: 88, color: 'bg-st-gold' },
    ],
    testimonials: [
      { text: 'Dr. Chen is incredibly kind and made my procedure much less daunting.', patient: 'Jessica P.', rating: 5 },
      { text: 'She is very knowledgeable and takes the time to answer all questions.', patient: 'Chris B.', rating: 5 },
    ],
    image: '/flower-512.png', // Placeholder
  },
  'dr-david-lee': {
    name: 'Dr. David Lee',
    role: 'Hygienist & Therapist',
    heroVideo: '/videos/david-lee-hero.mp4', // Placeholder video
    qualifications: ['BSc Oral Health Science'],
    experience: '7+ years',
    bio: 'David Lee is our dedicated hygienist and therapist, passionate about preventive dental care and helping patients maintain optimal oral health. He provides thorough cleanings, valuable oral hygiene advice, and a friendly, reassuring presence.',
    specialties: [
      { name: 'Oral Hygiene', percentage: 98, color: 'bg-st-turquoise' },
      { name: 'Gum Health', percentage: 95, color: 'bg-st-magenta' },
      { name: 'Stain Removal', percentage: 90, color: 'bg-st-gold' },
    ],
    testimonials: [
      { text: 'David is fantastic! My teeth feel so clean and he gave me great tips.', patient: 'Olivia M.', rating: 5 },
      { text: 'Always a pleasant experience with David. Highly recommend!', patient: 'Tom H.', rating: 5 },
    ],
    image: '/flower-512.png', // Placeholder
  },
  'dr-anna-jones': {
    name: 'Dr. Anna Jones',
    role: 'Dental Nurse & Treatment Coordinator',
    heroVideo: '/videos/anna-jones-hero.mp4', // Placeholder video
    qualifications: ['National Diploma in Dental Nursing'],
    experience: '12+ years',
    bio: 'Anna Jones is an integral part of our team, ensuring smooth patient journeys and assisting with various treatments. Her warm demeanor and extensive experience make her a comforting presence for patients and a valuable asset to our practice.',
    specialties: [
      { name: 'Patient Comfort', percentage: 99, color: 'bg-st-turquoise' },
      { name: 'Treatment Coordination', percentage: 95, color: 'bg-st-magenta' },
      { name: 'Sterilization Protocols', percentage: 97, color: 'bg-st-gold' },
    ],
    testimonials: [
      { text: 'Anna is so lovely and helpful. She made me feel so much better about my visit.', patient: 'Chloe S.', rating: 5 },
      { text: 'Always greeted with a smile and made to feel welcome.', patient: 'Ben W.', rating: 5 },
    ],
    image: '/flower-512.png', // Placeholder
  },
};

interface ClinicianPageProps {
  params: { clinicianName: string };
}

export default function ClinicianPage({ params }: ClinicianPageProps) {
  const clinician = cliniciansData[params.clinicianName as keyof typeof cliniciansData];

  if (!clinician) {
    return notFound();
  }

  const videoRef = useRef<HTMLVideoElement>(null);
  const [isVideoPlaying, setIsVideoPlaying] = useState(true);
  const [isVideoMuted, setIsVideoMuted] = useState(true);

  useEffect(() => {
    if (videoRef.current) {
      if (isVideoPlaying) {
        videoRef.current.play();
      } else {
        videoRef.current.pause();
      }
    }
  }, [isVideoPlaying]);

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.muted = isVideoMuted;
    }
  }, [isVideoMuted]);

  return (
    <div className="container mx-auto px-4 py-12">
      <nav className="text-gray-600 mb-8" aria-label="breadcrumb">
        <ol className="list-none p-0 inline-flex">
          <li className="flex items-center">
            <Link href="/" className="hover:text-st-turquoise">Home</Link>
            <ChevronRight className="h-4 w-4 mx-2" />
          </li>
          <li className="flex items-center">
            <Link href="/team" className="hover:text-st-turquoise">Our Team</Link>
            <ChevronRight className="h-4 w-4 mx-2" />
          </li>
          <li className="flex items-center text-st-turquoise">
            {clinician.name}
          </li>
        </ol>
      </nav>

      {/* Hero Section with Video */}
      <section className="relative w-full h-[50vh] lg:h-[70vh] overflow-hidden rounded-lg shadow-xl mb-16">
        <video
          ref={videoRef}
          className="absolute top-0 left-0 w-full h-full object-cover"
          src={clinician.heroVideo}
          autoPlay
          loop
          muted={isVideoMuted}
          playsInline
          aria-label={`${clinician.name} promotional video`}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/50 to-transparent flex items-end p-8 lg:p-16">
          <div className="text-white">
            <h1 className="text-4xl lg:text-6xl font-bold leading-tight mb-2">
              {clinician.name}
            </h1>
            <p className="text-xl lg:text-3xl font-medium text-st-turquoise mb-4">
              {clinician.role}
            </p>
            <div className="flex space-x-4">
              <Button
                size="sm"
                variant="ghost"
                className="bg-white/20 text-white hover:bg-white/40 video-control-btn glowing"
                onClick={() => setIsVideoPlaying(!isVideoPlaying)}
                aria-label={isVideoPlaying ? "Pause video" : "Play video"}
              >
                {isVideoPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
              </Button>
              <Button
                size="sm"
                variant="ghost"
                className="bg-white/20 text-white hover:bg-white/40 video-control-btn glowing"
                onClick={() => setIsVideoMuted(!isVideoMuted)}
                aria-label={isVideoMuted ? "Unmute video" : "Mute video"}
              >
                {isVideoMuted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Bio and Qualifications */}
      <section className="grid lg:grid-cols-3 gap-12 mb-16">
        <div className="lg:col-span-2">
          <h2 className="text-3xl font-bold text-st-dark-grey mb-6">About {clinician.name}</h2>
          <p className="text-lg text-gray-700 mb-6">{clinician.bio}</p>
          
          <h3 className="text-2xl font-bold text-st-dark-grey mb-4">Qualifications</h3>
          <ul className="space-y-2 text-lg text-gray-700">
            {clinician.qualifications.map((qual, index) => (
              <li key={index} className="flex items-center"><GraduationCap className="h-5 w-5 text-st-turquoise mr-3" />{qual}</li>
            ))}
          </ul>
          
          <h3 className="text-2xl font-bold text-st-dark-grey mt-6 mb-4">Experience</h3>
          <p className="text-lg text-gray-700 flex items-center"><Briefcase className="h-5 w-5 text-st-turquoise mr-3" />{clinician.experience}</p>
        </div>
        <div className="flex flex-col items-center">
          <Image 
            src={clinician.image} 
            alt={`Portrait of ${clinician.name}`}
            width={300}
            height={300}
            className="rounded-full shadow-lg mb-6 nautical-border"
          />
          <Button variant="turquoise" size="lg">Book with {clinician.name}</Button>
        </div>
      </section>

      {/* Specialties / Skill Meters */}
      <section className="mb-16">
        <h2 className="text-3xl font-bold text-st-dark-grey mb-6 text-center">Areas of Expertise</h2>
        <div className="max-w-2xl mx-auto">
          {clinician.specialties.map((spec, index) => (
            <SkillMeter key={index} skill={spec.name} percentage={spec.percentage} color={spec.color} />
          ))}
        </div>
      </section>

      {/* Clinician Testimonials */}
      <section className="mb-16">
        <h2 className="text-3xl font-bold text-st-dark-grey mb-6 text-center">Patient Testimonials for {clinician.name}</h2>
        <div className="grid md:grid-cols-2 gap-8">
          {clinician.testimonials.map((testimonial, index) => (
            <Card key={index} className="luxury-card">
              <CardContent className="p-6">
                <div className="flex mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 text-st-gold fill-current" />
                  ))}
                </div>
                <p className="text-gray-700 italic mb-4">"{testimonial.text}"</p>
                <p className="font-semibold text-st-dark-grey">- {testimonial.patient}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Call to Action */}
      <section className="text-center py-16 bg-st-magenta rounded-lg shadow-lg">
        <h2 className="text-4xl font-bold text-white mb-4">Ready to Meet {clinician.name}?</h2>
        <p className="text-xl text-white mb-8">Schedule your consultation today and experience personalized care.</p>
        <Button variant="turquoise" size="lg" className="btn-sparkle">Book Appointment</Button>
      </section>
    </div>
  );
}


