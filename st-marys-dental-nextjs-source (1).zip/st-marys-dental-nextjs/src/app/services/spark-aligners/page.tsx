
'use client';
import React from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { ChevronRight, CheckCircle, Lightbulb, Video, HelpCircle, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import ThreeDModelViewer from '@/components/ThreeDModelViewer';

export default function SparkAlignersPage() {
  const faqs = [
    {
      question: "What are Spark Aligners?",
      answer: "Spark Aligners are a series of custom-made, clear, removable aligners that gradually straighten your teeth. They are a discreet and comfortable alternative to traditional braces."
    },
    {
      question: "How long does Spark Aligner treatment take?",
      answer: "Treatment duration varies depending on the complexity of your case, but typically ranges from 6 to 18 months. We'll provide a personalized treatment plan during your consultation."
    },
    {
      question: "Are Spark Aligners comfortable?",
      answer: "Yes, Spark Aligners are made from a smooth, comfortable plastic material that fits snugly over your teeth. They are designed to minimize discomfort, and most patients adjust to them quickly."
    },
    {
      question: "Can I eat and drink normally with Spark Aligners?",
      answer: "You should remove your Spark Aligners before eating or drinking anything other than water. This helps maintain their clarity and prevents damage. After eating, brush your teeth before putting your aligners back in."
    },
    {
      question: "How often do I need to wear my aligners?",
      answer: "For optimal results, you should wear your Spark Aligners for 20-22 hours per day, removing them only for eating, drinking, brushing, and flossing."
    }
  ];

  const videoGallery = [
    { id: 'video1', title: 'Introduction to Spark Aligners', url: 'https://www.youtube.com/embed/your-spark-video-id-1' },
    { id: 'video2', title: 'The Spark Aligner Journey', url: 'https://www.youtube.com/embed/your-spark-video-id-2' },
    { id: 'video3', title: 'Caring for Your Spark Aligners', url: 'https://www.youtube.com/embed/your-spark-video-id-3' },
  ];

  const timelineEvents = [
    { year: 2000, description: 'Invisalign introduced as a clear aligner alternative.' },
    { year: 2010, description: 'Advancements in 3D printing technology improve aligner precision.' },
    { year: 2017, description: 'Spark Aligners launched, offering superior clarity and comfort.' },
    { year: 2020, description: 'St Mary\'s House Dental Care adopts Spark Aligners as a premium treatment option.' },
    { year: 2023, description: 'Integration of AI-powered treatment planning for Spark Aligners.' },
  ];

  return (
    <div className="container mx-auto px-4 py-12">
      <nav className="text-gray-600 mb-8" aria-label="breadcrumb">
        <ol className="list-none p-0 inline-flex">
          <li className="flex items-center">
            <Link href="/" className="hover:text-st-turquoise">Home</Link>
            <ChevronRight className="h-4 w-4 mx-2" />
          </li>
          <li className="flex items-center">
            <Link href="/services" className="hover:text-st-turquoise">Services</Link>
            <ChevronRight className="h-4 w-4 mx-2" />
          </li>
          <li className="flex items-center text-st-turquoise">
            Spark Aligners
          </li>
        </ol>
      </nav>

      <h1 className="text-5xl lg:text-6xl font-bold text-st-dark-grey mb-8">Spark Aligners</h1>

      <section className="grid lg:grid-cols-2 gap-12 mb-16">
        <div>
          <p className="text-lg text-gray-700 mb-6">
            Spark Aligners offer a discreet, comfortable, and highly effective solution for straightening your teeth. 
            Utilizing advanced clear aligner technology, Spark provides superior clarity and stain resistance, 
            making your orthodontic journey virtually invisible.
          </p>
          <p className="text-lg text-gray-700 mb-6">
            At St Mary's House Dental Care, we leverage the precision of Spark Aligners to craft personalized treatment plans 
            that gently guide your teeth into their ideal position, ensuring a beautiful and healthy smile.
          </p>
          <ul className="space-y-3 text-lg text-gray-700">
            <li className="flex items-center"><CheckCircle className="h-6 w-6 text-st-turquoise mr-3" />Virtually invisible treatment</li>
            <li className="flex items-center"><CheckCircle className="h-6 w-6 text-st-turquoise mr-3" />Comfortable and removable</li>
            <li className="flex items-center"><CheckCircle className="h-6 w-6 text-st-turquoise mr-3" />Predictable and effective results</li>
            <li className="flex items-center"><CheckCircle className="h-6 w-6 text-st-turquoise mr-3" />Advanced clear material for superior aesthetics</li>
          </ul>
          <Button variant="sparkle" size="lg" className="mt-8">Book Your Spark Consultation</Button>
        </div>
        <div className="relative w-full h-96 rounded-lg overflow-hidden shadow-xl nautical-border">
          <Image 
            src="/spark-aligners-hero.jpg" // Placeholder image
            alt="Close-up of Spark Aligners on teeth"
            layout="fill"
            objectFit="cover"
            className="rounded-lg"
          />
        </div>
      </section>

      {/* 3D Model Section */}
      <section className="mb-16">
        <h2 className="text-4xl font-bold text-st-dark-grey mb-6 text-center">Explore Spark Aligners in 3D</h2>
        <p className="text-center text-lg text-gray-700 mb-8">Interact with a 3D model of Spark Aligners to understand their design and how they work.</p>
        <div className="w-full h-96 bg-gray-100 rounded-lg shadow-lg flex items-center justify-center nautical-border">
          <ThreeDModelViewer modelPath="/models/spark-aligner.glb" scale={0.1} /> {/* Placeholder GLB model */} 
        </div>
      </section>

      {/* FAQ Section */}
      <section className="mb-16">
        <h2 className="text-4xl font-bold text-st-dark-grey mb-6 text-center">Frequently Asked Questions</h2>
        <Accordion type="single" collapsible className="w-full max-w-3xl mx-auto">
          {faqs.map((faq, index) => (
            <AccordionItem value={`item-${index + 1}`} key={index}>
              <AccordionTrigger className="text-lg font-semibold text-st-dark-grey hover:text-st-turquoise">
                <HelpCircle className="h-5 w-5 mr-3 text-st-magenta" />{faq.question}
              </AccordionTrigger>
              <AccordionContent className="text-gray-700 text-base pl-8">
                {faq.answer}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </section>

      {/* Video Gallery */}
      <section className="mb-16">
        <h2 className="text-4xl font-bold text-st-dark-grey mb-6 text-center">Video Gallery</h2>
        <p className="text-center text-lg text-gray-700 mb-8">Watch videos to learn more about Spark Aligners and the treatment process.</p>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {videoGallery.map((video) => (
            <Card key={video.id} className="luxury-card">
              <CardHeader>
                <CardTitle className="text-st-dark-grey flex items-center"><Video className="mr-2" />{video.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="relative w-full" style={{ paddingBottom: '56.25%' }}>
                  <iframe
                    className="absolute top-0 left-0 w-full h-full rounded-lg"
                    src={video.url}
                    title={video.title}
                    frameBorder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  ></iframe>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Interactive Timeline */}
      <section className="mb-16">
        <h2 className="text-4xl font-bold text-st-dark-grey mb-6 text-center">Evolution of Clear Aligners</h2>
        <p className="text-center text-lg text-gray-700 mb-8">Discover key milestones in the development of clear aligner technology.</p>
        <div className="relative border-l-2 border-st-turquoise pl-8">
          {timelineEvents.map((event, index) => (
            <div key={index} className="mb-8 last:mb-0 relative">
              <div className="absolute -left-4 top-0 flex items-center justify-center w-8 h-8 bg-st-turquoise rounded-full text-white font-bold">
                <Clock className="h-5 w-5" />
              </div>
              <Card className="luxury-card ml-4">
                <CardHeader>
                  <CardTitle className="text-st-dark-grey">{event.year}</CardTitle>
                </CardHeader>
                <CardContent className="text-gray-700">
                  {event.description}
                </CardContent>
              </Card>
            </div>
          ))}
        </div>
      </section>

      {/* Call to Action */}
      <section className="text-center py-16 bg-st-turquoise rounded-lg shadow-lg">
        <h2 className="text-4xl font-bold text-white mb-4">Ready for Your New Smile?</h2>
        <p className="text-xl text-white mb-8">Contact us today to schedule your Spark Aligners consultation.</p>
        <Button variant="gold" size="lg" className="btn-sparkle">Schedule Appointment</Button>
      </section>
    </div>
  );
}


