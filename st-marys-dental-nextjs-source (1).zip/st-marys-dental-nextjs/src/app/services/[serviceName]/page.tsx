
// This is a dynamic route for service pages
// You can fetch data based on serviceName from a CMS or API

import React from 'react';
import { notFound } from 'next/navigation';
import Image from 'next/image';
import Link from 'next/link';
import { ChevronRight, CheckCircle, Lightbulb, Video, HelpCircle, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import ThreeDModelViewer from '@/components/ThreeDModelViewer';

// Mock data for services - in a real app, this would come from a database or CMS
const serviceData = {
  'spark-aligners': {
    title: 'Spark Aligners',
    description: 'Spark Aligners offer a discreet, comfortable, and highly effective solution for straightening your teeth. Utilizing advanced clear aligner technology, Spark provides superior clarity and stain resistance, making your orthodontic journey virtually invisible.',
    benefits: [
      'Virtually invisible treatment',
      'Comfortable and removable',
      'Predictable and effective results',
      'Advanced clear material for superior aesthetics',
    ],
    heroImage: '/spark-aligners-hero.jpg',
    modelPath: '/models/spark-aligner.glb',
    faqs: [
      {
        question: 'What are Spark Aligners?',
        answer: 'Spark Aligners are a series of custom-made, clear, removable aligners that gradually straighten your teeth. They are a discreet and comfortable alternative to traditional braces.'
      },
      {
        question: 'How long does Spark Aligner treatment take?',
        answer: 'Treatment duration varies depending on the complexity of your case, but typically ranges from 6 to 18 months. We\'ll provide a personalized treatment plan during your consultation.'
      },
      {
        question: 'Are Spark Aligners comfortable?',
        answer: 'Yes, Spark Aligners are made from a smooth, comfortable plastic material that fits snugly over your teeth. They are designed to minimize discomfort, and most patients adjust to them quickly.'
      },
      {
        question: 'Can I eat and drink normally with Spark Aligners?',
        answer: 'You should remove your Spark Aligners before eating or drinking anything other than water. This helps maintain their clarity and prevents damage. After eating, brush your teeth before putting your aligners back in.'
      },
      {
        question: 'How often do I need to wear my aligners?',
        answer: 'For optimal results, you should wear your Spark Aligners for 20-22 hours per day, removing them only for eating, drinking, brushing, and flossing.'
      }
    ],
    videoGallery: [
      { id: 'video1', title: 'Introduction to Spark Aligners', url: 'https://www.youtube.com/embed/your-spark-video-id-1' },
      { id: 'video2', title: 'The Spark Aligner Journey', url: 'https://www.youtube.com/embed/your-spark-video-id-2' },
      { id: 'video3', title: 'Caring for Your Spark Aligners', url: 'https://www.youtube.com/embed/your-spark-video-id-3' },
    ],
    timelineEvents: [
      { year: 2000, description: 'Invisalign introduced as a clear aligner alternative.' },
      { year: 2010, description: 'Advancements in 3D printing technology improve aligner precision.' },
      { year: 2017, description: 'Spark Aligners launched, offering superior clarity and comfort.' },
      { year: 2020, description: 'St Mary\'s House Dental Care adopts Spark Aligners as a premium treatment option.' },
      { year: 2023, description: 'Integration of AI-powered treatment planning for Spark Aligners.' },
    ],
  },
  '3d-printed-veneers': {
    title: '3D Printed Veneers',
    description: 'Experience the future of cosmetic dentistry with our precision-crafted 3D Printed Veneers. Using state-of-the-art technology, we design and create veneers that perfectly match your natural teeth, ensuring a flawless and durable smile transformation.',
    benefits: [
      'Custom-designed for a perfect fit',
      'Durable and long-lasting material',
      'Minimally invasive procedure',
      'Rapid fabrication with 3D printing',
    ],
    heroImage: '/3d-veneers-hero.jpg',
    modelPath: '/models/veneer.glb',
    faqs: [
      { question: 'What are 3D Printed Veneers?', answer: 'They are custom-made, thin shells of tooth-colored material designed to cover the front surface of teeth to improve their appearance.' },
      { question: 'How long do they last?', answer: 'With proper care, 3D printed veneers can last 10-15 years or even longer.' },
    ],
    videoGallery: [
      { id: 'video4', title: 'The Process of 3D Printed Veneers', url: 'https://www.youtube.com/embed/your-veneer-video-id-1' },
    ],
    timelineEvents: [
      { year: 2015, description: 'Early adoption of 3D printing in dentistry.' },
      { year: 2020, description: 'Significant advancements in dental 3D printing materials.' },
    ],
  },
  'surgically-guided-implants': {
    title: 'Surgically-Guided Implants',
    description: 'Our surgically-guided implant procedures utilize advanced 3D imaging and planning software to ensure precise and safe implant placement. This innovative approach minimizes discomfort and significantly improves long-term success rates.',
    benefits: [
      'Highly precise placement',
      'Reduced surgical time and discomfort',
      'Enhanced safety and predictability',
      'Optimal aesthetic and functional outcomes',
    ],
    heroImage: '/implants-hero.jpg',
    modelPath: '/models/implant.glb',
    faqs: [
      { question: 'What are dental implants?', answer: 'Dental implants are artificial tooth roots that are surgically placed into your jawbone to hold a replacement tooth or bridge.' },
      { question: 'What is surgical guidance?', answer: 'It\'s a technique using 3D imaging to plan the exact position, angle, and depth for implant placement, ensuring precision.' },
    ],
    videoGallery: [
      { id: 'video5', title: 'Understanding Dental Implants', url: 'https://www.youtube.com/embed/your-implant-video-id-1' },
    ],
    timelineEvents: [
      { year: 1965, description: 'First successful dental implant by Branemark.' },
      { year: 2005, description: 'Introduction of cone-beam CT for dental imaging.' },
    ],
  },
  'the-wand-system': {
    title: 'The Wand System',
    description: 'Experience virtually painless anesthesia with The Wand System. This computer-controlled local anesthetic delivery system provides a comfortable and anxiety-free injection experience, making dental visits more pleasant for all our patients.',
    benefits: [
      'Virtually painless injections',
      'Reduced anxiety',
      'Precise anesthetic delivery',
      'Faster onset of numbness',
    ],
    heroImage: '/wand-hero.jpg',
    modelPath: '/models/wand.glb',
    faqs: [
      { question: 'How does The Wand work?', answer: 'It uses a computer-controlled system to deliver anesthetic at a slow, steady rate, minimizing the stinging sensation often associated with injections.' },
    ],
    videoGallery: [
      { id: 'video6', title: 'The Wand System Explained', url: 'https://www.youtube.com/embed/your-wand-video-id-1' },
    ],
    timelineEvents: [
      { year: 1997, description: 'The Wand System introduced.' },
      { year: 2010, description: 'Widespread adoption in pain-free dentistry.' },
    ],
  },
  'teeth-whitening': {
    title: 'Teeth Whitening',
    description: 'Achieve a brighter, more confident smile with our professional teeth whitening treatments. We offer safe and effective solutions to remove stains and discoloration, revealing a noticeably whiter smile in just one visit.',
    benefits: [
      'Safe and effective',
      'Noticeably whiter smile',
      'Customized treatment plans',
      'Long-lasting results',
    ],
    heroImage: '/whitening-hero.jpg',
    modelPath: '/models/teeth.glb',
    faqs: [
      { question: 'Is teeth whitening safe?', answer: 'Yes, when performed by a dental professional, teeth whitening is safe and effective.' },
      { question: 'How long do results last?', answer: 'Results vary, but typically last from several months to a few years, depending on your habits.' },
    ],
    videoGallery: [
      { id: 'video7', title: 'Professional Teeth Whitening', url: 'https://www.youtube.com/embed/your-whitening-video-id-1' },
    ],
    timelineEvents: [
      { year: 1989, description: 'First at-home whitening products.' },
      { year: 2000, description: 'In-office power whitening becomes popular.' },
    ],
  },
  'sedation-dentistry': {
    title: 'Sedation Dentistry',
    description: 'For patients with dental anxiety or those undergoing lengthy procedures, our sedation dentistry options provide a relaxed and comfortable experience. We offer various levels of sedation to ensure your visit is stress-free.',
    benefits: [
      'Reduces dental anxiety',
      'Comfortable for long procedures',
      'Safe and monitored',
      'Various sedation levels available',
    ],
    heroImage: '/sedation-hero.jpg',
    modelPath: '/models/sedation.glb',
    faqs: [
      { question: 'What types of sedation do you offer?', answer: 'We offer nitrous oxide (laughing gas), oral conscious sedation, and IV sedation.' },
      { question: 'Is sedation dentistry safe?', answer: 'Yes, all sedation procedures are carefully monitored by our trained professionals.' },
    ],
    videoGallery: [
      { id: 'video8', title: 'Relax with Sedation Dentistry', url: 'https://www.youtube.com/embed/your-sedation-video-id-1' },
    ],
    timelineEvents: [
      { year: 1844, description: 'First use of nitrous oxide in dentistry.' },
      { year: 1980, description: 'Development of modern oral conscious sedation.' },
    ],
  },
};

interface ServicePageProps {
  params: { serviceName: string };
}

export default function ServicePage({ params }: ServicePageProps) {
  const service = serviceData[params.serviceName as keyof typeof serviceData];

  if (!service) {
    notFound();
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <nav className="text-gray-600 mb-8" aria-label="breadcrumb">
        <ol className="list-none p-0 inline-flex">
          <li className="flex items-center">
            <Link href="/" className="hover:text-st-turquoise">Home</Link>
            <ChevronRight className="h-4 w-4 mx-2" />
          </li>
          <li className="flex items-center">
            <Link href="/services" className="hover:text-st-turquoise">Services</Link>
            <ChevronRight className="h-4 w-4 mx-2" />
          </li>
          <li className="flex items-center text-st-turquoise">
            {service.title}
          </li>
        </ol>
      </nav>

      <h1 className="text-5xl lg:text-6xl font-bold text-st-dark-grey mb-8">{service.title}</h1>

      <section className="grid lg:grid-cols-2 gap-12 mb-16">
        <div>
          <p className="text-lg text-gray-700 mb-6">
            {service.description}
          </p>
          <ul className="space-y-3 text-lg text-gray-700">
            {service.benefits.map((benefit, index) => (
              <li key={index} className="flex items-center"><CheckCircle className="h-6 w-6 text-st-turquoise mr-3" />{benefit}</li>
            ))}
          </ul>
          <Button variant="sparkle" size="lg" className="mt-8">Book Your {service.title} Consultation</Button>
        </div>
        <div className="relative w-full h-96 rounded-lg overflow-hidden shadow-xl nautical-border">
          <Image 
            src={service.heroImage} 
            alt={service.title}
            layout="fill"
            objectFit="cover"
            className="rounded-lg"
          />
        </div>
      </section>

      {/* 3D Model Section */}
      <section className="mb-16">
        <h2 className="text-4xl font-bold text-st-dark-grey mb-6 text-center">Explore {service.title} in 3D</h2>
        <p className="text-center text-lg text-gray-700 mb-8">Interact with a 3D model of {service.title} to understand their design and how they work.</p>
        <div className="w-full h-96 bg-gray-100 rounded-lg shadow-lg flex items-center justify-center nautical-border">
          <ThreeDModelViewer modelPath={service.modelPath} scale={0.1} />
        </div>
      </section>

      {/* FAQ Section */}
      <section className="mb-16">
        <h2 className="text-4xl font-bold text-st-dark-grey mb-6 text-center">Frequently Asked Questions</h2>
        <Accordion type="single" collapsible className="w-full max-w-3xl mx-auto">
          {service.faqs.map((faq, index) => (
            <AccordionItem value={`item-${index + 1}`} key={index}>
              <AccordionTrigger className="text-lg font-semibold text-st-dark-grey hover:text-st-turquoise">
                <HelpCircle className="h-5 w-5 mr-3 text-st-magenta" />{faq.question}
              </AccordionTrigger>
              <AccordionContent className="text-gray-700 text-base pl-8">
                {faq.answer}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </section>

      {/* Video Gallery */}
      <section className="mb-16">
        <h2 className="text-4xl font-bold text-st-dark-grey mb-6 text-center">Video Gallery</h2>
        <p className="text-center text-lg text-gray-700 mb-8">Watch videos to learn more about {service.title} and the treatment process.</p>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {service.videoGallery.map((video) => (
            <Card key={video.id} className="luxury-card">
              <CardHeader>
                <CardTitle className="text-st-dark-grey flex items-center"><Video className="mr-2" />{video.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="relative w-full" style={{ paddingBottom: '56.25%' }}>
                  <iframe
                    className="absolute top-0 left-0 w-full h-full rounded-lg"
                    src={video.url}
                    title={video.title}
                    frameBorder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  ></iframe>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Interactive Timeline */}
      <section className="mb-16">
        <h2 className="text-4xl font-bold text-st-dark-grey mb-6 text-center">Evolution of {service.title}</h2>
        <p className="text-center text-lg text-gray-700 mb-8">Discover key milestones in the development of {service.title} technology.</p>
        <div className="relative border-l-2 border-st-turquoise pl-8">
          {service.timelineEvents.map((event, index) => (
            <div key={index} className="mb-8 last:mb-0 relative">
              <div className="absolute -left-4 top-0 flex items-center justify-center w-8 h-8 bg-st-turquoise rounded-full text-white font-bold">
                <Clock className="h-5 w-5" />
              </div>
              <Card className="luxury-card ml-4">
                <CardHeader>
                  <CardTitle className="text-st-dark-grey">{event.year}</CardTitle>
                </CardHeader>
                <CardContent className="text-gray-700">
                  {event.description}
                </CardContent>
              </Card>
            </div>
          ))}
        </div>
      </section>

      {/* Call to Action */}
      <section className="text-center py-16 bg-st-turquoise rounded-lg shadow-lg">
        <h2 className="text-4xl font-bold text-white mb-4">Ready for Your New Smile?</h2>
        <p className="text-xl text-white mb-8">Contact us today to schedule your {service.title} consultation.</p>
        <Button variant="gold" size="lg" className="btn-sparkle">Schedule Appointment</Button>
      </section>
    </div>
  );
}


