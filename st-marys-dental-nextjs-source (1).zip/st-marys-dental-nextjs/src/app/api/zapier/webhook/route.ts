import { NextRequest, NextResponse } from 'next/server';

// Mock Zapier webhook handler for Dentally PMS integration
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    // Extract appointment data from the request
    const {
      patientName,
      patientEmail,
      patientPhone,
      appointmentType,
      preferredDate,
      preferredTime,
      notes,
      clinician
    } = body;

    // Validate required fields
    if (!patientName || !patientEmail || !appointmentType) {
      return NextResponse.json(
        { 
          error: 'Missing required fields',
          required: ['patientName', 'patientEmail', 'appointmentType']
        },
        { status: 400 }
      );
    }

    // Mock Zapier integration - In production, this would trigger a Zap
    const zapierPayload = {
      trigger: 'appointment_booking',
      data: {
        patient: {
          name: patientName,
          email: patientEmail,
          phone: patientPhone || null
        },
        appointment: {
          type: appointmentType,
          preferredDate: preferredDate || null,
          preferredTime: preferredTime || null,
          clinician: clinician || 'Any available',
          notes: notes || null
        },
        practice: {
          name: 'St Mary\'s House Dental Care',
          location: 'Shoreham-by-Sea'
        },
        timestamp: new Date().toISOString(),
        source: 'website_booking'
      }
    };

    // Mock response - In production, this would be the actual Zapier webhook URL
    console.log('Mock Zapier webhook triggered:', zapierPayload);

    // Simulate Dentally PMS integration response
    const mockDentallyResponse = {
      appointmentId: `SMHDC-${Date.now()}`,
      status: 'pending_confirmation',
      estimatedConfirmationTime: '2 hours',
      message: 'Appointment request received and forwarded to Dentally PMS'
    };

    return NextResponse.json({
      success: true,
      zapierTriggered: true,
      dentallyResponse: mockDentallyResponse,
      bookingReference: mockDentallyResponse.appointmentId,
      message: 'Appointment booking request has been successfully submitted to our practice management system.'
    });

  } catch (error) {
    console.error('Zapier webhook error:', error);
    
    return NextResponse.json({
      success: false,
      error: 'Failed to process appointment booking',
      message: 'There was an error processing your appointment request. Please contact us directly.'
    }, { status: 500 });
  }
}

// Handle GET request for webhook verification
export async function GET(request: NextRequest) {
  return NextResponse.json({
    webhook: 'St Mary\'s House Dental Care - Zapier Integration',
    status: 'active',
    integrations: ['Dentally PMS', 'Email notifications', 'Calendar sync'],
    timestamp: new Date().toISOString()
  });
}

// Handle OPTIONS request for CORS
export async function OPTIONS(request: NextRequest) {
  return new NextResponse(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    },
  });
}

