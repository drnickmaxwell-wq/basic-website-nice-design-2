import { NextRequest, NextResponse } from 'next/server';

// Appointment booking API that integrates with Zapier webhook
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    const {
      patientName,
      patientEmail,
      patientPhone,
      appointmentType,
      preferredDate,
      preferredTime,
      clinician,
      notes,
      source = 'website'
    } = body;

    // Validate required fields
    if (!patientName || !patientEmail || !appointmentType) {
      return NextResponse.json(
        { 
          error: 'Missing required fields',
          required: ['patientName', 'patientEmail', 'appointmentType'],
          message: 'Please fill in all required fields to book your appointment.'
        },
        { status: 400 }
      );
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(patientEmail)) {
      return NextResponse.json(
        { 
          error: 'Invalid email format',
          message: 'Please enter a valid email address.'
        },
        { status: 400 }
      );
    }

    // Generate booking reference
    const bookingReference = `SMHDC-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;

    // Prepare data for Zapier webhook
    const zapierData = {
      patientName,
      patientEmail,
      patientPhone: patientPhone || null,
      appointmentType,
      preferredDate: preferredDate || null,
      preferredTime: preferredTime || null,
      clinician: clinician || 'Any available',
      notes: notes || null,
      source,
      bookingReference,
      timestamp: new Date().toISOString(),
      practice: {
        name: 'St Mary\'s House Dental Care',
        location: 'Shoreham-by-Sea',
        phone: '+44 1273 123456',
        email: 'appointments@stmaryshousedental.co.uk'
      }
    };

    // Call Zapier webhook (mock implementation)
    try {
      // In production, this would be the actual Zapier webhook URL
      const zapierWebhookUrl = process.env.ZAPIER_WEBHOOK_URL || '/api/zapier/webhook';
      
      // Mock Zapier webhook call
      console.log('Triggering Zapier webhook with data:', zapierData);
      
      // Simulate webhook response
      const zapierResponse = {
        success: true,
        hookId: `hook_${Date.now()}`,
        status: 'accepted',
        message: 'Appointment booking forwarded to Dentally PMS'
      };

      // Send confirmation email (mock)
      const emailData = {
        to: patientEmail,
        subject: 'Appointment Booking Confirmation - St Mary\'s House Dental Care',
        template: 'appointment_confirmation',
        data: {
          patientName,
          bookingReference,
          appointmentType,
          preferredDate,
          preferredTime,
          clinician,
          practicePhone: '+44 1273 123456'
        }
      };

      console.log('Mock confirmation email sent:', emailData);

      return NextResponse.json({
        success: true,
        bookingReference,
        message: 'Your appointment booking has been successfully submitted!',
        details: {
          patientName,
          appointmentType,
          preferredDate,
          preferredTime,
          clinician,
          status: 'pending_confirmation',
          estimatedConfirmationTime: '2 hours',
          contactInfo: {
            phone: '+44 1273 123456',
            email: 'appointments@stmaryshousedental.co.uk'
          }
        },
        zapierResponse,
        nextSteps: [
          'You will receive a confirmation email shortly',
          'Our team will contact you within 2 hours to confirm your appointment',
          'Please check your email for further instructions'
        ]
      });

    } catch (zapierError) {
      console.error('Zapier webhook error:', zapierError);
      
      // Even if Zapier fails, we can still process the booking locally
      return NextResponse.json({
        success: true,
        bookingReference,
        message: 'Your appointment request has been received. Our team will contact you shortly.',
        details: {
          patientName,
          appointmentType,
          preferredDate,
          preferredTime,
          clinician,
          status: 'manual_processing_required'
        },
        warning: 'Automated processing temporarily unavailable. Manual processing initiated.'
      });
    }

  } catch (error) {
    console.error('Appointment booking error:', error);
    
    return NextResponse.json({
      success: false,
      error: 'Failed to process appointment booking',
      message: 'We apologize, but there was an error processing your appointment request. Please contact us directly at +44 1273 123456 or try again later.',
      contactInfo: {
        phone: '+44 1273 123456',
        email: 'appointments@stmaryshousedental.co.uk'
      }
    }, { status: 500 });
  }
}

// Handle GET request to retrieve appointment types and available slots
export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const action = searchParams.get('action');

  if (action === 'appointment-types') {
    const appointmentTypes = [
      {
        id: 'consultation',
        name: 'Initial Consultation',
        duration: 60,
        description: 'Comprehensive examination and treatment planning',
        price: 'Free'
      },
      {
        id: 'checkup',
        name: 'Regular Checkup',
        duration: 30,
        description: 'Routine dental examination and cleaning',
        price: '£85'
      },
      {
        id: 'hygienist',
        name: 'Hygienist Appointment',
        duration: 45,
        description: 'Professional cleaning and oral health advice',
        price: '£65'
      },
      {
        id: 'emergency',
        name: 'Emergency Appointment',
        duration: 30,
        description: 'Urgent dental care for pain or trauma',
        price: '£120'
      },
      {
        id: 'cosmetic-consultation',
        name: 'Cosmetic Consultation',
        duration: 45,
        description: 'Smile makeover and cosmetic treatment planning',
        price: 'Free'
      }
    ];

    return NextResponse.json({
      success: true,
      appointmentTypes,
      total: appointmentTypes.length
    });
  }

  if (action === 'clinicians') {
    const clinicians = [
      {
        id: 'dr-sarah-mitchell',
        name: 'Dr. Sarah Mitchell',
        role: 'Principal Dentist',
        specialties: ['Cosmetic Dentistry', 'Implantology', 'Sedation']
      },
      {
        id: 'dr-james-thompson',
        name: 'Dr. James Thompson',
        role: 'Associate Dentist',
        specialties: ['Orthodontics', 'Restorative Dentistry']
      },
      {
        id: 'dr-emily-chen',
        name: 'Dr. Emily Chen',
        role: 'Associate Dentist',
        specialties: ['Periodontics', 'Oral Surgery']
      },
      {
        id: 'david-lee',
        name: 'David Lee',
        role: 'Hygienist & Therapist',
        specialties: ['Oral Hygiene', 'Preventive Care']
      }
    ];

    return NextResponse.json({
      success: true,
      clinicians,
      total: clinicians.length
    });
  }

  return NextResponse.json({
    service: 'Appointment Booking API',
    status: 'active',
    available_actions: ['appointment-types', 'clinicians'],
    integrations: ['Zapier', 'Dentally PMS', 'Email notifications'],
    timestamp: new Date().toISOString()
  });
}

// Handle OPTIONS request for CORS
export async function OPTIONS(request: NextRequest) {
  return new NextResponse(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    },
  });
}

