import { NextRequest, NextResponse } from 'next/server';

// Mock HeyGen API integration for avatar video generation
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    const {
      text,
      avatar_id,
      voice_id,
      background,
      aspect_ratio = '16:9',
      quality = 'high'
    } = body;

    // Validate required fields
    if (!text || !avatar_id) {
      return NextResponse.json(
        { 
          error: 'Missing required fields',
          required: ['text', 'avatar_id']
        },
        { status: 400 }
      );
    }

    // Mock HeyGen API payload
    const heygenPayload = {
      video_inputs: [{
        character: {
          type: 'avatar',
          avatar_id: avatar_id,
          avatar_style: 'normal'
        },
        voice: {
          type: 'text',
          input_text: text,
          voice_id: voice_id || 'default_english_female'
        },
        background: {
          type: background || 'dental_office',
          url: background === 'custom' ? '/backgrounds/dental-office.jpg' : null
        }
      }],
      aspect_ratio: aspect_ratio,
      quality: quality,
      callback_id: `heygen_${Date.now()}`,
      test: true // Set to false in production
    };

    // Generate mock video ID
    const mockVideoId = `heygen_${Date.now()}`;
    const estimatedDuration = Math.ceil(text.length / 200) * 60; // Rough estimate: 200 chars per minute

    console.log('Mock HeyGen video generation:', heygenPayload);

    // Mock response simulating HeyGen API
    const mockResponse = {
      code: 100, // HeyGen success code
      data: {
        video_id: mockVideoId,
        status: 'pending',
        created_at: new Date().toISOString(),
        callback_id: heygenPayload.callback_id,
        estimated_time: estimatedDuration
      },
      message: 'Video generation task created successfully',
      metadata: {
        avatar_id: avatar_id,
        voice_id: voice_id || 'default_english_female',
        text_length: text.length,
        estimated_duration: `${Math.ceil(estimatedDuration / 60)} minutes`
      }
    };

    return NextResponse.json({
      success: true,
      heygen_response: mockResponse,
      video_id: mockVideoId,
      status_check_url: `/api/heygen/status/${mockVideoId}`,
      message: 'Avatar video generation started successfully. Check status using the provided URL.'
    });

  } catch (error) {
    console.error('HeyGen API error:', error);
    
    return NextResponse.json({
      success: false,
      error: 'Failed to generate avatar video',
      message: 'There was an error starting the avatar video generation process. Please try again later.'
    }, { status: 500 });
  }
}

// Handle GET request for available avatars
export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const action = searchParams.get('action');

  if (action === 'avatars') {
    // Mock available avatars for dental practice
    const mockAvatars = [
      {
        avatar_id: 'dental_professional_1',
        name: 'Dr. Sarah (Professional)',
        gender: 'female',
        style: 'professional',
        preview_url: '/avatars/previews/sarah.jpg'
      },
      {
        avatar_id: 'dental_professional_2',
        name: 'Dr. James (Friendly)',
        gender: 'male',
        style: 'friendly',
        preview_url: '/avatars/previews/james.jpg'
      },
      {
        avatar_id: 'dental_assistant_1',
        name: 'Emma (Assistant)',
        gender: 'female',
        style: 'approachable',
        preview_url: '/avatars/previews/emma.jpg'
      }
    ];

    return NextResponse.json({
      success: true,
      avatars: mockAvatars,
      total: mockAvatars.length
    });
  }

  if (action === 'voices') {
    // Mock available voices
    const mockVoices = [
      {
        voice_id: 'en_female_professional',
        name: 'Professional Female (UK)',
        language: 'en-GB',
        gender: 'female',
        style: 'professional'
      },
      {
        voice_id: 'en_male_friendly',
        name: 'Friendly Male (UK)',
        language: 'en-GB',
        gender: 'male',
        style: 'friendly'
      },
      {
        voice_id: 'en_female_warm',
        name: 'Warm Female (UK)',
        language: 'en-GB',
        gender: 'female',
        style: 'warm'
      }
    ];

    return NextResponse.json({
      success: true,
      voices: mockVoices,
      total: mockVoices.length
    });
  }

  return NextResponse.json({
    service: 'HeyGen Avatar Video Generation',
    status: 'active',
    available_actions: ['avatars', 'voices'],
    timestamp: new Date().toISOString()
  });
}

// Handle OPTIONS request for CORS
export async function OPTIONS(request: NextRequest) {
  return new NextResponse(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    },
  });
}

