import { NextRequest, NextResponse } from 'next/server';

// Mock HeyGen video status check
export async function GET(
  request: NextRequest,
  { params }: { params: { videoId: string } }
) {
  try {
    const { videoId } = params;

    if (!videoId) {
      return NextResponse.json(
        { error: 'Video ID is required' },
        { status: 400 }
      );
    }

    // Mock status check - In production, this would call HeyGen's status API
    const mockStatuses = ['pending', 'processing', 'completed', 'failed'];
    const randomStatus = mockStatuses[Math.floor(Math.random() * mockStatuses.length)];

    // For demo purposes, let's assume most videos are completed
    const status = Math.random() > 0.3 ? 'completed' : randomStatus;

    const mockResponse = {
      code: 100,
      data: {
        video_id: videoId,
        status: status,
        created_at: new Date(Date.now() - 300000).toISOString(), // 5 minutes ago
        updated_at: new Date().toISOString(),
        video_url: status === 'completed' ? `/videos/heygen/${videoId}.mp4` : null,
        thumbnail_url: status === 'completed' ? `/videos/heygen/thumbnails/${videoId}.jpg` : null,
        duration: status === 'completed' ? 45 : null, // seconds
        error: status === 'failed' ? 'Video generation failed due to invalid input' : null
      },
      message: status === 'completed' ? 'Video generated successfully' : 
               status === 'failed' ? 'Video generation failed' :
               'Video is being processed'
    };

    return NextResponse.json({
      success: true,
      heygen_response: mockResponse,
      video_ready: status === 'completed',
      download_url: mockResponse.data.video_url,
      message: mockResponse.message
    });

  } catch (error) {
    console.error('HeyGen status check error:', error);
    
    return NextResponse.json({
      success: false,
      error: 'Failed to check video status',
      message: 'There was an error checking the video generation status.'
    }, { status: 500 });
  }
}

// Handle OPTIONS request for CORS
export async function OPTIONS(request: NextRequest) {
  return new NextResponse(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    },
  });
}

