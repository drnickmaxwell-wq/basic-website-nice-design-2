import { NextRequest, NextResponse } from 'next/server';
import OpenAI from 'openai';

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// System prompt for the dental chatbot
const SYSTEM_PROMPT = `You are a helpful AI assistant for St Mary's House Dental Care, a luxury dental practice in Shoreham-by-Sea. 

Your role is to:
- Provide information about dental treatments and services
- Help patients understand procedures and what to expect
- Answer questions about appointments and practice policies
- Offer general dental health advice
- Guide users to book appointments when appropriate

Available treatments include:
- Spark Aligners (clear orthodontic aligners)
- 3D Printed Veneers (cosmetic dental veneers)
- Surgically-Guided Implants (precision dental implants)
- The Wand System (painless anesthesia delivery)
- Teeth Whitening (professional whitening treatments)
- Sedation Dentistry (anxiety management)

Practice information:
- Location: Shoreham-by-Sea, West Sussex
- Luxury coastal dental practice
- Advanced technology and personalized care
- GDPR compliant and patient-focused

Always be professional, empathetic, and helpful. If you don't know something specific about the practice, suggest the patient contact the practice directly or book a consultation.`;

export async function POST(request: NextRequest) {
  try {
    const { message, conversationHistory = [] } = await request.json();

    if (!message) {
      return NextResponse.json(
        { error: 'Message is required' },
        { status: 400 }
      );
    }

    // Prepare messages for OpenAI
    const messages = [
      { role: 'system', content: SYSTEM_PROMPT },
      ...conversationHistory,
      { role: 'user', content: message }
    ];

    // Call OpenAI API
    const completion = await openai.chat.completions.create({
      model: 'gpt-3.5-turbo',
      messages: messages as any,
      max_tokens: 500,
      temperature: 0.7,
    });

    const response = completion.choices[0]?.message?.content || 'I apologize, but I encountered an error. Please try again or contact our practice directly.';

    return NextResponse.json({
      response,
      timestamp: new Date().toISOString(),
    });

  } catch (error) {
    console.error('Chatbot API error:', error);
    
    // Return a fallback response if OpenAI fails
    return NextResponse.json({
      response: "I'm currently experiencing technical difficulties. Please contact St Mary's House Dental Care directly at your convenience, or try again later.",
      timestamp: new Date().toISOString(),
      error: 'Service temporarily unavailable'
    }, { status: 500 });
  }
}

// Handle OPTIONS request for CORS
export async function OPTIONS(request: NextRequest) {
  return new NextResponse(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    },
  });
}

