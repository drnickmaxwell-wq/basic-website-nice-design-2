
'use client';
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ChevronDown, Play, Pause, VolumeX, Volume2, Accessibility, Calendar, Award, Shield, Heart, Sparkles, Star } from "lucide-react"
import Header from "@/components/Header"
import ServiceCard from "@/components/ServiceCard"
import TeamMemberCard from "@/components/TeamMemberCard"
import TestimonialCard from "@/components/TestimonialCard"
import AccessibilityWidget from "@/components/AccessibilityWidget"
import ChatBot from "@/components/ChatBot"
import BookingModal from "@/components/BookingModal"
import React, { useState, useEffect, useRef } from 'react'
import { Badge } from "@/components/ui/badge"

export default function Home() {
  const [isDarkMode, setIsDarkMode] = useState(false); // Placeholder for dark mode toggle, will be handled in Header component
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);
  const [preselectedService, setPreselectedService] = useState<string | undefined>(undefined);
  const [isVideoPlaying, setIsVideoPlaying] = useState(true)
  const [isVideoMuted, setIsVideoMuted] = useState(true)
  const [scrollY, setScrollY] = useState(0)
  const videoRef = useRef<HTMLVideoElement>(null);

  // Handle scroll for parallax effects
  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY)
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  useEffect(() => {
    if (videoRef.current) {
      if (isVideoPlaying) {
        videoRef.current.play();
      } else {
        videoRef.current.pause();
      }
    }
  }, [isVideoPlaying]);

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.muted = isVideoMuted;
    }
  }, [isVideoMuted]);

  // Functions to handle booking
  const openBookingModal = (serviceType?: string) => {
    setPreselectedService(serviceType);
    setIsBookingModalOpen(true);
  };

  const closeBookingModal = () => {
    setIsBookingModalOpen(false);
    setPreselectedService(undefined);
  };

  // Services data (moved from App.jsx)
  const services = [
    {
      title: "Spark Aligners",
      description: "Clear, comfortable aligners for a perfect smile transformation",
      icon: "✨",
      color: "turquoise"
    },
    {
      title: "3D Printed Veneers",
      description: "Precision-crafted veneers using advanced 3D printing technology",
      icon: "🦷",
      color: "magenta"
    },
    {
      title: "Surgically-Guided Implants",
      description: "State-of-the-art implant placement with surgical precision",
      icon: "⚕️",
      color: "gold"
    },
    {
      title: "The Wand System",
      description: "Painless numbing system for ultimate comfort during procedures",
      icon: "🪄",
      color: "turquoise"
    },
    {
      title: "Teeth Whitening",
      description: "Professional whitening for a brighter, more confident smile",
      icon: "⭐",
      color: "magenta"
    },
    {
      title: "Sedation Dentistry",
      description: "Relax completely with our gentle sedation options",
      icon: "😌",
      color: "gold"
    }
  ]

  // Team members (moved from App.jsx)
  const teamMembers = [
    {
      name: "Dr. Sarah Mitchell",
      role: "Principal Dentist & Owner",
      specialties: ["Cosmetic Dentistry", "Implantology", "Sedation"],
      experience: "15+ years",
      image: "/flower-512.png" // Placeholder
    },
    {
      name: "Dr. James Thompson",
      role: "Associate Dentist",
      specialties: ["Orthodontics", "Restorative Dentistry"],
      experience: "10+ years",
      image: "/flower-512.png" // Placeholder
    },
    {
      name: "Dr. Emily Chen",
      role: "Associate Dentist",
      specialties: ["Periodontics", "Oral Surgery"],
      experience: "8+ years",
      image: "/flower-512.png" // Placeholder
    }
  ]

  // Testimonials (moved from App.jsx)
  const testimonials = [
    {
      name: "Sophie Williams",
      treatment: "Spark Aligners",
      rating: 5,
      text: "The team at St Mary's transformed my smile completely. The Spark aligners were so comfortable, and the results exceeded my expectations!",
      location: "Shoreham-by-Sea"
    },
    {
      name: "Michael Roberts",
      treatment: "Dental Implants",
      rating: 5,
      text: "Professional, caring, and incredibly skilled. The surgically-guided implant procedure was painless thanks to The Wand system.",
      location: "Brighton"
    },
    {
      name: "Emma Thompson",
      treatment: "3D Printed Veneers",
      rating: 5,
      text: "Amazing technology and even better results. My new veneers look completely natural and feel perfect.",
      location: "Worthing"
    }
  ]

  return (
    <div className={`min-h-screen ${isDarkMode ? 'dark' : ''}`}>
      {/* Skip to main content link for screen readers */}
      <a href="#main-content" className="skip-link">
        Skip to main content
      </a>
      
      <Header />

      {/* Main content wrapper */}
      <main id="main-content">
        {/* Hero Section */}
        <section id="home" className="relative w-full h-screen overflow-hidden" role="banner">
          <video 
            ref={videoRef}
            className="absolute top-0 left-0 w-full h-full object-cover"
            src="/hero-video.mp4" // Placeholder for hero video
            autoPlay
            loop
            muted={isVideoMuted}
            playsInline
            aria-label="St Mary's House Dental Care promotional video"
          />
          <div 
            className="absolute inset-0 bg-gradient-to-r from-black/40 to-transparent"
            style={{ transform: `translateY(${scrollY * 0.3}px)` }} // Parallax effect will be implemented later
          />
          
          <div className="container mx-auto px-4 relative z-10 flex items-center justify-center h-full">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              {/* Hero Content */}
              <div className="text-white space-y-6">
                <Badge className="bg-st-gold text-white px-4 py-2 text-sm font-medium gold-sparkle">
                  <Award className="mr-2 h-4 w-4" aria-hidden="true" />
                  Premium Dental Care by the Sea
                </Badge>
                
                <h1 className="text-5xl lg:text-7xl font-bold leading-tight">
                  Transform Your
                  <span className="text-st-turquoise block wave-animation">
                    Smile by the Sea
                  </span>
                </h1>
                
                <p className="text-xl lg:text-2xl text-gray-200 max-w-2xl">
                  Experience luxury dental care at St Mary's House, Shoreham-by-Sea. 
                  Where advanced technology meets coastal tranquility for your perfect smile.
                </p>
                
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button 
                    variant="sparkle" 
                    size="lg" 
                    className="text-lg px-8 py-4 turquoise-glow"
                    onClick={() => openBookingModal('consultation')}
                  >
                    <Calendar className="mr-2 h-5 w-5" aria-hidden="true" />
                    Book Your Consultation
                  </Button>
                  <Button variant="magenta" size="lg" className="text-lg px-8 py-4">
                    <Play className="mr-2 h-5 w-5" aria-hidden="true" />
                    Take Our Smile Quiz
                  </Button>
                </div>
                
                <div className="flex items-center space-x-6 pt-4">
                  <div className="flex items-center space-x-2">
                    <div className="flex" role="img" aria-label="5 star rating">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="h-5 w-5 text-st-gold fill-current" aria-hidden="true" />
                      ))}
                    </div>
                    <span className="text-white">5.0 Rating</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Shield className="h-5 w-5 text-st-turquoise" aria-hidden="true" />
                    <span className="text-white">GDPR Compliant</span>
                  </div>
                </div>
              </div>

              {/* Hero Video Controls */}
              <div className="absolute bottom-4 right-4 flex space-x-2">
                <Button
                  size="sm"
                  variant="ghost"
                  className="bg-black/20 text-white hover:bg-black/40"
                  onClick={() => setIsVideoPlaying(!isVideoPlaying)}
                  aria-label={isVideoPlaying ? "Pause video" : "Play video"}
                >
                  {isVideoPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  className="bg-black/20 text-white hover:bg-black/40"
                  onClick={() => setIsVideoMuted(!isVideoMuted)}
                  aria-label={isVideoMuted ? "Unmute video" : "Mute video"}
                >
                  {isVideoMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
                </Button>
              </div>
            </div>
          </div>

          {/* Scroll Indicator */}
          <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2" aria-hidden="true">
            <div className="w-6 h-10 border-2 border-white rounded-full flex justify-center">
              <div className="w-1 h-3 bg-white rounded-full mt-2 wave-animation"></div>
            </div>
          </div>
        </section>

        {/* Services Section */}
        <section id="services" className="py-20 bg-gradient-to-b from-white to-gray-50" aria-labelledby="services-heading">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <Badge className="bg-st-turquoise text-white px-4 py-2 mb-4">
                <Sparkles className="mr-2 h-4 w-4" aria-hidden="true" />
                Our Services
              </Badge>
              <h2 id="services-heading" className="text-4xl lg:text-6xl font-bold text-st-dark-grey mb-6">
                Advanced Dental Care
                <span className="text-st-magenta block">Tailored for You</span>
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                From routine care to complex procedures, we offer comprehensive dental services 
                using the latest technology and techniques in our coastal practice.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8" role="list">
              {services.map((service, index) => (
                <div key={index} role="listitem">
                  <ServiceCard {...service} onBookNow={openBookingModal} />
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* About Section */}
        <section id="about" className="py-20 bg-white" aria-labelledby="about-heading">
          <div className="container mx-auto px-4">
            <div className="grid lg:grid-cols-2 gap-16 items-center">
              <div>
                <Badge className="bg-st-magenta text-white px-4 py-2 mb-4">
                  <Heart className="mr-2 h-4 w-4" aria-hidden="true" />
                  About Us
                </Badge>
                <h2 id="about-heading" className="text-4xl lg:text-5xl font-bold text-st-dark-grey mb-6">
                  Coastal Dental Excellence
                  <span className="text-st-turquoise block">Since 2010</span>
                </h2>
                <p className="text-lg text-gray-600 mb-6">
                  Located in the heart of Shoreham-by-Sea, St Mary's House Dental Care combines 
                  cutting-edge dental technology with the calming influence of our coastal setting. 
                  Our team of experienced professionals is dedicated to providing exceptional care 
                  in a relaxing, luxury environment.
                </p>
                <div className="space-y-4 mb-8">
                  <div className="flex items-center space-x-3">
                    <Award className="h-6 w-6 text-st-gold" aria-hidden="true" />
                    <p className="text-lg text-st-dark-grey">Award-winning dental practice</p>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Shield className="h-6 w-6 text-st-gold" aria-hidden="true" />
                    <p className="text-lg text-st-dark-grey">Committed to patient safety and comfort</p>
                  </div>
                </div>
                <Button variant="turquoise" size="lg">Learn More About Our Story</Button>
              </div>
              <div>
                <Image 
                  src="/vertical-caps-turquoise-1024.png" 
                  alt="St Mary's House Dental Care clinic exterior showing modern coastal architecture with turquoise branding"
                  width={500}
                  height={500}
                  className="rounded-lg shadow-xl mx-auto nautical-border"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Team Section */}
        <section id="team" className="py-20 bg-st-light-grey" aria-labelledby="team-heading">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <Badge className="bg-st-gold text-white px-4 py-2 mb-4">
                <Sparkles className="mr-2 h-4 w-4" aria-hidden="true" />
                Our Professionals
              </Badge>
              <h2 id="team-heading" className="text-4xl lg:text-6xl font-bold text-st-dark-grey mb-6">
                Meet Our Expert Team
                <span className="text-st-magenta block">Dedicated to Your Smile</span>
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Our highly skilled and compassionate team is committed to providing you with the highest standard of dental care.
              </p>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8" role="list">
              {teamMembers.map((member, index) => (
                <div key={index} role="listitem">
                  <TeamMemberCard {...member} />
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Patient Stories Section */}
        <section id="stories" className="py-20 bg-white" aria-labelledby="stories-heading">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <Badge className="bg-st-turquoise text-white px-4 py-2 mb-4">
                <Sparkles className="mr-2 h-4 w-4" aria-hidden="true" />
                Patient Journeys
              </Badge>
              <h2 id="stories-heading" className="text-4xl lg:text-6xl font-bold text-st-dark-grey mb-6">
                Our Patient's Radiant Smiles
                <span className="text-st-magenta block">Real Transformations</span>
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Hear directly from our happy patients about their experiences and the life-changing results they achieved.
              </p>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8" role="list">
              {testimonials.map((testimonial, index) => (
                <div key={index} role="listitem">
                  <TestimonialCard {...testimonial} />
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section id="contact" className="py-20 bg-st-light-grey" aria-labelledby="contact-heading">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <Badge className="bg-st-magenta text-white px-4 py-2 mb-4">
                <Sparkles className="mr-2 h-4 w-4" aria-hidden="true" />
                Get in Touch
              </Badge>
              <h2 id="contact-heading" className="text-4xl lg:text-6xl font-bold text-st-dark-grey mb-6">
                Contact Us
                <span className="text-st-turquoise block">Your Journey Starts Here</span>
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                We are here to answer all your questions and help you schedule your next visit.
              </p>
            </div>
            <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-12">
              <div className="space-y-6 text-st-dark-grey">
                <address className="not-italic">
                  <p className="font-lora text-lg">St Mary's House Dental Care</p>
                  <p className="font-lora text-lg">St Mary's House, St Mary's Road</p>
                  <p className="font-lora text-lg">Shoreham-by-Sea, West Sussex BN43 5ZA</p>
                  <p className="font-lora text-lg">
                    <span className="sr-only">Telephone: </span>
                    TEL: <a href="tel:01273453109" className="hover:text-st-turquoise transition-colors">01273 453109</a>
                  </p>
                  <p className="font-lora text-lg">
                    Email: <a href="mailto:info@smhdental.co.uk" className="hover:text-st-turquoise transition-colors">info@smhdental.co.uk</a>
                  </p>
                </address>
                <div className="flex space-x-4">
                  <Button variant="turquoise" size="lg">Book Online</Button>
                  <Button variant="magenta" size="lg">Call Us Now</Button>
                </div>
              </div>
              <div className="w-full h-64 bg-st-light-grey rounded-lg flex items-center justify-center text-st-dark-grey/50 nautical-border" role="img" aria-label="Interactive map placeholder - map will be loaded here">
                <p>Interactive Map Placeholder</p>
              </div>
            </div>
          </div>
        </section>

      {/* Footer */}
      <footer className="bg-st-dark-grey text-st-light-grey py-12 px-8" role="contentinfo">
        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-4">
            <Image 
              src="/flower-512.png" 
              alt="St Mary's House Dental Care logo - stylized flower design in turquoise and magenta" 
              width={60} 
              height={60} 
              style={{objectFit: "contain"}} 
            />
            <p className="font-lora text-sm">Going the Extra Smile</p>
            <div className="flex space-x-4">
              {/* Social Media Icons Placeholder */}
            </div>
          </div>
          <nav aria-labelledby="footer-nav-1">
            <h3 id="footer-nav-1" className="font-montserrat font-semibold text-lg mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><Link href="#home" className="hover:text-st-turquoise transition-colors">Home</Link></li>
              <li><Link href="#services" className="hover:text-st-turquoise transition-colors">Services</Link></li>
              <li><Link href="#about" className="hover:text-st-turquoise transition-colors">About Us</Link></li>
              <li><Link href="#team" className="hover:text-st-turquoise transition-colors">Our Team</Link></li>
              <li><Link href="#stories" className="hover:text-st-turquoise transition-colors">Patient Stories</Link></li>
              <li><Link href="#contact" className="hover:text-st-turquoise transition-colors">Contact</Link></li>
            </ul>
          </nav>
          <nav aria-labelledby="footer-nav-2">
            <h3 id="footer-nav-2" className="font-montserrat font-semibold text-lg mb-4">Legal</h3>
            <ul className="space-y-2">
              <li><Link href="/privacy-policy" className="hover:text-st-turquoise transition-colors">Privacy Policy</Link></li>
              <li><Link href="/cookie-policy" className="hover:text-st-turquoise transition-colors">Cookie Policy</Link></li>
              <li><Link href="/terms-of-service" className="hover:text-st-turquoise transition-colors">Terms of Service</Link></li>
            </ul>
          </nav>
          <div>
            <h3 className="font-montserrat font-semibold text-lg mb-4">Connect With Us</h3>
            <p className="font-lora text-sm">Stay up to date with our latest news and offers.</p>
            {/* Newsletter Signup Placeholder */}
          </div>
        </div>
        <div className="mt-8 pt-8 border-t border-st-light-grey/20 text-center text-sm">
          <p>&copy; {new Date().getFullYear()} St Mary's House Dental Care. All Rights Reserved.</p>
        </div>
        </div>
      </main>

      {/* Accessibility Widget */}
      <AccessibilityWidget />

      {/* ChatBot */}
      <ChatBot 
        isOpen={isChatOpen} 
        onToggle={() => setIsChatOpen(!isChatOpen)} 
      />

      {/* Booking Modal */}
      <BookingModal 
        isOpen={isBookingModalOpen}
        onClose={closeBookingModal}
        preselectedService={preselectedService}
      />
    </div>
  )
}


