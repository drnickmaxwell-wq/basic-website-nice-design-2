import type { Metadata } from "next"
import { Montserrat, Lora } from "next/font/google"
import "./globals.css"
import { cn } from "@/lib/utils"

const montserrat = Montserrat({ subsets: ["latin"], variable: "--font-montserrat" })
const lora = Lora({ subsets: ["latin"], variable: "--font-lora" })

export const metadata: Metadata = {
  title: "St Mary\'s House Dental Care - Going the Extra Smile | Luxury Dental Shoreham-by-Sea",
  description: "Premium dental care at St Mary\'s House, Shoreham-by-Sea. Luxury treatments including Spark Aligners, 3D Printed Veneers, Implants & The Wand System. Going the Extra Smile.",
  keywords: "luxury dental clinic Shoreham-by-Sea, coastal dental care West Sussex, premium dentist, Spark Aligners, 3D printed veneers, dental implants, teeth whitening",
  openGraph: {
    title: "St Mary\'s House Dental Care - Going the Extra Smile",
    description: "Experience luxury dental care by the sea in Shoreham-by-Sea, West Sussex. Advanced treatments with a personal touch.",
    type: "website",
  },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className={cn("min-h-screen bg-background font-lora antialiased", montserrat.variable, lora.variable)}>
        {children}
      </body>
    </html>
  )
}
