
import { Card, CardContent } from "@/components/ui/card";
import { Star } from "lucide-react";

interface TestimonialCardProps {
  name: string;
  treatment: string;
  rating: number;
  text: string;
  location: string;
}

const TestimonialCard: React.FC<TestimonialCardProps> = ({ name, treatment, rating, text, location }) => {
  return (
    <Card className="luxury-card">
      <CardContent>
        <div className="flex text-st-gold mb-2">
          {[...Array(rating)].map((_, i) => (
            <Star key={i} className="h-5 w-5 text-st-gold fill-current" />
          ))}
        </div>
        <p className="font-lora text-st-dark-grey italic mb-4">"{text}"</p>
        <p className="font-montserrat font-semibold text-st-dark-grey">- {name}, {location}</p>
        <p className="text-sm text-gray-500">Treatment: {treatment}</p>
      </CardContent>
    </Card>
  );
};

export default TestimonialCard;


