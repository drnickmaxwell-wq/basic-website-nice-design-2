'use client';
import React, { useState, useEffect } from 'react';
import { X, Calendar, Clock, User, Mail, Phone, FileText, CheckCircle, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  preselectedService?: string;
}

interface AppointmentType {
  id: string;
  name: string;
  duration: number;
  description: string;
  price: string;
}

interface Clinician {
  id: string;
  name: string;
  role: string;
  specialties: string[];
}

interface BookingFormData {
  patientName: string;
  patientEmail: string;
  patientPhone: string;
  appointmentType: string;
  preferredDate: string;
  preferredTime: string;
  clinician: string;
  notes: string;
}

export default function BookingModal({ isOpen, onClose, preselectedService }: BookingModalProps) {
  const [step, setStep] = useState(1);
  const [appointmentTypes, setAppointmentTypes] = useState<AppointmentType[]>([]);
  const [clinicians, setClinicians] = useState<Clinician[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [bookingResult, setBookingResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const [formData, setFormData] = useState<BookingFormData>({
    patientName: '',
    patientEmail: '',
    patientPhone: '',
    appointmentType: preselectedService || '',
    preferredDate: '',
    preferredTime: '',
    clinician: '',
    notes: ''
  });

  // Load appointment types and clinicians when modal opens
  useEffect(() => {
    if (isOpen) {
      loadAppointmentData();
    }
  }, [isOpen]);

  // Reset form when modal closes
  useEffect(() => {
    if (!isOpen) {
      setStep(1);
      setBookingResult(null);
      setError(null);
      setFormData({
        patientName: '',
        patientEmail: '',
        patientPhone: '',
        appointmentType: preselectedService || '',
        preferredDate: '',
        preferredTime: '',
        clinician: '',
        notes: ''
      });
    }
  }, [isOpen, preselectedService]);

  const loadAppointmentData = async () => {
    setIsLoading(true);
    try {
      // Load appointment types
      const typesResponse = await fetch('/api/appointments/book?action=appointment-types');
      const typesData = await typesResponse.json();
      if (typesData.success) {
        setAppointmentTypes(typesData.appointmentTypes);
      }

      // Load clinicians
      const cliniciansResponse = await fetch('/api/appointments/book?action=clinicians');
      const cliniciansData = await cliniciansResponse.json();
      if (cliniciansData.success) {
        setClinicians(cliniciansData.clinicians);
      }
    } catch (error) {
      console.error('Error loading appointment data:', error);
      setError('Failed to load appointment options. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleInputChange = (field: keyof BookingFormData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    setError(null);
  };

  const validateStep = (stepNumber: number): boolean => {
    switch (stepNumber) {
      case 1:
        return !!(formData.patientName && formData.patientEmail && formData.appointmentType);
      case 2:
        return !!(formData.preferredDate && formData.preferredTime);
      case 3:
        return true; // Optional step
      default:
        return false;
    }
  };

  const nextStep = () => {
    if (validateStep(step)) {
      setStep(step + 1);
    } else {
      setError('Please fill in all required fields before continuing.');
    }
  };

  const prevStep = () => {
    setStep(step - 1);
    setError(null);
  };

  const submitBooking = async () => {
    if (!validateStep(1) || !validateStep(2)) {
      setError('Please fill in all required fields.');
      return;
    }

    setIsSubmitting(true);
    setError(null);

    try {
      const response = await fetch('/api/appointments/book', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...formData,
          source: 'website_booking_modal'
        }),
      });

      const data = await response.json();

      if (data.success) {
        setBookingResult(data);
        setStep(4); // Success step
      } else {
        setError(data.message || 'Failed to book appointment. Please try again.');
      }
    } catch (error) {
      console.error('Booking error:', error);
      setError('Failed to submit booking. Please contact us directly at +44 1273 123456.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const generateTimeSlots = () => {
    const slots = [];
    for (let hour = 9; hour <= 17; hour++) {
      for (let minute = 0; minute < 60; minute += 30) {
        if (hour === 17 && minute > 0) break; // Don't go past 5:00 PM
        const time = `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;
        slots.push(time);
      }
    }
    return slots;
  };

  const getMinDate = () => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    return tomorrow.toISOString().split('T')[0];
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <CardHeader className="bg-st-turquoise text-white">
          <div className="flex items-center justify-between">
            <CardTitle className="text-xl font-semibold flex items-center">
              <Calendar className="mr-2 h-5 w-5" />
              Book Your Appointment
            </CardTitle>
            <Button
              size="sm"
              variant="ghost"
              className="text-white hover:bg-white/20"
              onClick={onClose}
              aria-label="Close booking modal"
            >
              <X className="h-5 w-5" />
            </Button>
          </div>
          
          {/* Progress Indicator */}
          <div className="flex items-center space-x-2 mt-4">
            {[1, 2, 3, 4].map((stepNumber) => (
              <div
                key={stepNumber}
                className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold ${
                  stepNumber <= step
                    ? 'bg-white text-st-turquoise'
                    : 'bg-white/30 text-white'
                }`}
              >
                {stepNumber === 4 && bookingResult ? (
                  <CheckCircle className="h-4 w-4" />
                ) : (
                  stepNumber
                )}
              </div>
            ))}
          </div>
        </CardHeader>

        <CardContent className="p-6">
          {error && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg flex items-center text-red-700">
              <AlertCircle className="h-4 w-4 mr-2" />
              {error}
            </div>
          )}

          {/* Step 1: Personal Information & Service */}
          {step === 1 && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-st-dark-grey mb-4">Personal Information & Service</h3>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Full Name *
                </label>
                <input
                  type="text"
                  value={formData.patientName}
                  onChange={(e) => handleInputChange('patientName', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-st-turquoise"
                  placeholder="Enter your full name"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Email Address *
                </label>
                <input
                  type="email"
                  value={formData.patientEmail}
                  onChange={(e) => handleInputChange('patientEmail', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-st-turquoise"
                  placeholder="Enter your email address"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Phone Number
                </label>
                <input
                  type="tel"
                  value={formData.patientPhone}
                  onChange={(e) => handleInputChange('patientPhone', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-st-turquoise"
                  placeholder="Enter your phone number"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Appointment Type *
                </label>
                <select
                  value={formData.appointmentType}
                  onChange={(e) => handleInputChange('appointmentType', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-st-turquoise"
                  required
                >
                  <option value="">Select an appointment type</option>
                  {appointmentTypes.map((type) => (
                    <option key={type.id} value={type.id}>
                      {type.name} ({type.duration} mins) - {type.price}
                    </option>
                  ))}
                </select>
                {formData.appointmentType && (
                  <p className="text-sm text-gray-600 mt-1">
                    {appointmentTypes.find(t => t.id === formData.appointmentType)?.description}
                  </p>
                )}
              </div>

              <div className="flex justify-end">
                <Button onClick={nextStep} className="bg-st-turquoise hover:bg-st-turquoise/90">
                  Next Step
                </Button>
              </div>
            </div>
          )}

          {/* Step 2: Date & Time */}
          {step === 2 && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-st-dark-grey mb-4">Preferred Date & Time</h3>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Preferred Date *
                </label>
                <input
                  type="date"
                  value={formData.preferredDate}
                  onChange={(e) => handleInputChange('preferredDate', e.target.value)}
                  min={getMinDate()}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-st-turquoise"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Preferred Time *
                </label>
                <select
                  value={formData.preferredTime}
                  onChange={(e) => handleInputChange('preferredTime', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-st-turquoise"
                  required
                >
                  <option value="">Select a time</option>
                  {generateTimeSlots().map((time) => (
                    <option key={time} value={time}>
                      {time}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Preferred Clinician
                </label>
                <select
                  value={formData.clinician}
                  onChange={(e) => handleInputChange('clinician', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-st-turquoise"
                >
                  <option value="">Any available clinician</option>
                  {clinicians.map((clinician) => (
                    <option key={clinician.id} value={clinician.id}>
                      {clinician.name} - {clinician.role}
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex justify-between">
                <Button variant="outline" onClick={prevStep}>
                  Previous
                </Button>
                <Button onClick={nextStep} className="bg-st-turquoise hover:bg-st-turquoise/90">
                  Next Step
                </Button>
              </div>
            </div>
          )}

          {/* Step 3: Additional Information */}
          {step === 3 && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-st-dark-grey mb-4">Additional Information</h3>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Additional Notes
                </label>
                <textarea
                  value={formData.notes}
                  onChange={(e) => handleInputChange('notes', e.target.value)}
                  rows={4}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-st-turquoise"
                  placeholder="Any additional information, concerns, or special requirements..."
                />
              </div>

              <div className="bg-st-light-grey p-4 rounded-lg">
                <h4 className="font-semibold text-st-dark-grey mb-2">Booking Summary</h4>
                <div className="space-y-1 text-sm">
                  <p><strong>Name:</strong> {formData.patientName}</p>
                  <p><strong>Email:</strong> {formData.patientEmail}</p>
                  <p><strong>Service:</strong> {appointmentTypes.find(t => t.id === formData.appointmentType)?.name}</p>
                  <p><strong>Date:</strong> {formData.preferredDate}</p>
                  <p><strong>Time:</strong> {formData.preferredTime}</p>
                  {formData.clinician && (
                    <p><strong>Clinician:</strong> {clinicians.find(c => c.id === formData.clinician)?.name}</p>
                  )}
                </div>
              </div>

              <div className="flex justify-between">
                <Button variant="outline" onClick={prevStep}>
                  Previous
                </Button>
                <Button 
                  onClick={submitBooking} 
                  disabled={isSubmitting}
                  className="bg-st-turquoise hover:bg-st-turquoise/90"
                >
                  {isSubmitting ? 'Booking...' : 'Confirm Booking'}
                </Button>
              </div>
            </div>
          )}

          {/* Step 4: Confirmation */}
          {step === 4 && bookingResult && (
            <div className="text-center space-y-4">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle className="h-8 w-8 text-green-600" />
              </div>
              
              <h3 className="text-2xl font-bold text-st-dark-grey">Booking Confirmed!</h3>
              
              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <p className="text-green-800 font-semibold">
                  Booking Reference: {bookingResult.bookingReference}
                </p>
                <p className="text-green-700 mt-2">
                  {bookingResult.message}
                </p>
              </div>

              <div className="text-left bg-gray-50 p-4 rounded-lg">
                <h4 className="font-semibold text-st-dark-grey mb-2">Next Steps:</h4>
                <ul className="space-y-1 text-sm text-gray-700">
                  {bookingResult.nextSteps?.map((step: string, index: number) => (
                    <li key={index} className="flex items-start">
                      <span className="text-st-turquoise mr-2">•</span>
                      {step}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="text-sm text-gray-600">
                <p>Contact us: {bookingResult.details?.contactInfo?.phone}</p>
                <p>Email: {bookingResult.details?.contactInfo?.email}</p>
              </div>

              <Button onClick={onClose} className="bg-st-turquoise hover:bg-st-turquoise/90">
                Close
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

