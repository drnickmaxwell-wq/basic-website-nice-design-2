
import React, { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Menu, X, ChevronDown, Calendar } from 'lucide-react';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);

  const navigationItems = [
    { name: 'Home', href: '#home' },
    {
      name: 'Services',
      href: '#services',
      dropdown: [
        'General Dentistry',
        'Spark Aligners',
        'Surgically-Guided Implants',
        '3D Printed Veneers',
        'Teeth Whitening',
        'Composite Bonding',
        'The Wand System',
        'Sedation Dentistry',
      ],
    },
    { name: 'About Us', href: '#about' },
    { name: 'Patient Stories', href: '#stories' },
    { name: 'Blog', href: '#blog' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <nav className="nav-sticky">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center space-x-3">
            <Image
              src="/flower-512.png"
              alt="St Mary's House Dental Care Logo"
              width={40}
              height={40}
              className="wave-animation"
            />
            <div className="hidden md:block">
              <h1 className="text-xl font-bold text-st-turquoise">
                St Mary's House Dental Care
              </h1>
              <p className="text-sm text-st-magenta">Going the Extra Smile</p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center space-x-6">
            {navigationItems.map((item, index) => (
              <div key={index} className="relative group">
                <Link href={item.href} className="nav-item flex items-center">
                  {item.name}
                  {item.dropdown && <ChevronDown className="ml-1 h-4 w-4" />}
                </Link>
                {item.dropdown && (
                  <div className="absolute top-full left-0 mt-2 w-64 bg-white rounded-lg shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 z-50">
                    <div className="p-2">
                      {item.dropdown.map((subItem, subIndex) => (
                        <Link
                          key={subIndex}
                          href={`#${subItem.toLowerCase().replace(/\s+/g, '-')}`}
                          className="block px-4 py-2 text-sm text-gray-700 hover:bg-st-turquoise hover:text-white rounded transition-colors"
                        >
                          {subItem}
                        </Link>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* CTA Buttons */}
          <div className="hidden md:flex items-center space-x-4">
            <Button className="btn-turquoise shimmer-effect">
              <Calendar className="mr-2 h-4 w-4" />
              Book Appointment
            </Button>
            <Button
              variant="outline"
              onClick={() => setIsDarkMode(!isDarkMode)}
              className="border-st-turquoise text-st-turquoise hover:bg-st-turquoise hover:text-white"
            >
              {isDarkMode ? '☀️' : '🌙'}
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <Button
            variant="ghost"
            size="sm"
            className="lg:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </Button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="lg:hidden bg-white border-t border-st-light-grey">
          <div className="px-4 py-2 space-y-2">
            {navigationItems.map((item, index) => (
              <Link
                key={index}
                href={item.href}
                className="block px-4 py-2 text-sm text-gray-700 hover:bg-st-turquoise hover:text-white rounded transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                {item.name}
              </Link>
            ))}
            <Button className="btn-turquoise w-full mt-4">
              <Calendar className="mr-2 h-4 w-4" />
              Book Appointment
            </Button>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Header;


