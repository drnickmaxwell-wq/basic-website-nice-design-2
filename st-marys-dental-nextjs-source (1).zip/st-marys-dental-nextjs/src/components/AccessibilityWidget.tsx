'use client';
import React, { useState, useEffect } from 'react';
import { Accessibility, Plus, Minus, Eye, EyeOff, Type, Contrast } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface AccessibilityWidgetProps {
  className?: string;
}

export default function AccessibilityWidget({ className = '' }: AccessibilityWidgetProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [fontSize, setFontSize] = useState(100);
  const [highContrast, setHighContrast] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(false);

  useEffect(() => {
    // Apply font size changes
    document.documentElement.style.fontSize = `${fontSize}%`;
  }, [fontSize]);

  useEffect(() => {
    // Apply high contrast mode
    if (highContrast) {
      document.documentElement.classList.add('high-contrast');
    } else {
      document.documentElement.classList.remove('high-contrast');
    }
  }, [highContrast]);

  useEffect(() => {
    // Apply reduced motion preference
    if (reducedMotion) {
      document.documentElement.classList.add('reduce-motion');
    } else {
      document.documentElement.classList.remove('reduce-motion');
    }
  }, [reducedMotion]);

  const increaseFontSize = () => {
    if (fontSize < 150) {
      setFontSize(fontSize + 10);
    }
  };

  const decreaseFontSize = () => {
    if (fontSize > 80) {
      setFontSize(fontSize - 10);
    }
  };

  const resetSettings = () => {
    setFontSize(100);
    setHighContrast(false);
    setReducedMotion(false);
  };

  return (
    <div className={`fixed bottom-4 right-4 z-50 ${className}`}>
      {/* Accessibility Panel */}
      {isOpen && (
        <div className="mb-4 bg-white rounded-lg shadow-xl border border-gray-200 p-4 w-64">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-gray-800">Accessibility Options</h3>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsOpen(false)}
              aria-label="Close accessibility panel"
            >
              ×
            </Button>
          </div>

          <div className="space-y-4">
            {/* Font Size Controls */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Text Size: {fontSize}%
              </label>
              <div className="flex items-center space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={decreaseFontSize}
                  disabled={fontSize <= 80}
                  aria-label="Decrease text size"
                >
                  <Minus className="h-4 w-4" />
                </Button>
                <span className="text-sm text-gray-600 flex-1 text-center">
                  {fontSize}%
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={increaseFontSize}
                  disabled={fontSize >= 150}
                  aria-label="Increase text size"
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* High Contrast Toggle */}
            <div>
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={highContrast}
                  onChange={(e) => setHighContrast(e.target.checked)}
                  className="rounded border-gray-300"
                />
                <span className="text-sm text-gray-700">High Contrast</span>
                <Contrast className="h-4 w-4 text-gray-500" />
              </label>
            </div>

            {/* Reduced Motion Toggle */}
            <div>
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={reducedMotion}
                  onChange={(e) => setReducedMotion(e.target.checked)}
                  className="rounded border-gray-300"
                />
                <span className="text-sm text-gray-700">Reduce Motion</span>
                <Eye className="h-4 w-4 text-gray-500" />
              </label>
            </div>

            {/* Reset Button */}
            <Button
              variant="outline"
              size="sm"
              onClick={resetSettings}
              className="w-full"
            >
              Reset to Default
            </Button>
          </div>
        </div>
      )}

      {/* Accessibility Toggle Button */}
      <Button
        onClick={() => setIsOpen(!isOpen)}
        className="accessibility-icon turquoise-glow"
        aria-label="Open accessibility options"
        aria-expanded={isOpen}
      >
        <Accessibility className="h-6 w-6" />
      </Button>
    </div>
  );
}

