
'use client';
import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';

interface SkillMeterProps {
  skill: string;
  percentage: number;
  color?: string; // Tailwind CSS color class, e.g., 'bg-st-turquoise'
}

export default function SkillMeter({ skill, percentage, color = 'bg-st-turquoise' }: SkillMeterProps) {
  const [isVisible, setIsVisible] = useState(false);
  const ref = React.useRef(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.5 } // Trigger when 50% of the component is visible
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => {
      if (ref.current) {
        observer.unobserve(ref.current);
      }
    };
  }, []);

  return (
    <div className="mb-4" ref={ref}>
      <div className="flex justify-between mb-1">
        <span className="text-lg font-medium text-st-dark-grey">{skill}</span>
        <span className="text-lg font-medium text-st-dark-grey">{percentage}%</span>
      </div>
      <div className="w-full bg-gray-200 rounded-full h-2.5">
        <motion.div
          className={`h-2.5 rounded-full ${color}`}
          initial={{ width: 0 }}
          animate={isVisible ? { width: `${percentage}%` } : { width: 0 }}
          transition={{ duration: 1.5, ease: "easeOut" }}
        ></motion.div>
      </div>
    </div>
  );
}


