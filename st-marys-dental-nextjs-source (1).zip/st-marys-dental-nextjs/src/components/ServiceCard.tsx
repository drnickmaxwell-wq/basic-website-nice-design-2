
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { Calendar, ArrowRight } from "lucide-react";
import { slugify } from "@/lib/slugify";

interface ServiceCardProps {
  title: string;
  description: string;
  icon: string;
  color: "turquoise" | "magenta" | "gold";
  onBookNow?: (serviceType: string) => void;
}

const ServiceCard: React.FC<ServiceCardProps> = ({ title, description, icon, color, onBookNow }) => {
  return (
    <Card className="luxury-card group cursor-pointer">
      <CardHeader>
        <div className={`text-4xl mb-4 ${
          color === 'turquoise' ? 'turquoise-glow' :
          color === 'magenta' ? 'magenta-glow' : 'gold-sparkle'
        }`}>
          {icon}
        </div>
        <CardTitle className="text-xl font-bold text-st-dark-grey group-hover:text-st-turquoise transition-colors">
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-gray-600 mb-4">
          {description}
        </p>
        <div className="space-y-2">
          <Link href={`/services/${slugify(title)}`} passHref>
            <Button 
              variant="outline" 
              className={`w-full border-st-${color} text-st-${color} hover:bg-st-${color} hover:text-white`}
            >
              <ArrowRight className="mr-2 h-4 w-4" />
              Learn More
            </Button>
          </Link>
          {onBookNow && (
            <Button 
              onClick={() => onBookNow(slugify(title))}
              className={`w-full bg-st-${color} hover:bg-st-${color}/90 text-white`}
            >
              <Calendar className="mr-2 h-4 w-4" />
              Book Now
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default ServiceCard;


