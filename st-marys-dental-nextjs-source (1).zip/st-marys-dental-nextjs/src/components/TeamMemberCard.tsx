
import Image from "next/image";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { slugify } from "@/lib/slugify";

interface TeamMemberCardProps {
  name: string;
  role: string;
  specialties: string[];
  experience: string;
  image: string;
}

const TeamMemberCard: React.FC<TeamMemberCardProps> = ({ name, role, specialties, experience, image }) => {
  return (
    <Card className="luxury-card text-center">
      <div className="relative w-32 h-32 mx-auto mb-4 rounded-full overflow-hidden border-4 border-st-turquoise shadow-lg">
        <Image src={image} alt={name} layout="fill" objectFit="cover" />
      </div>
      <h3 className="text-xl font-bold text-st-dark-grey mb-1">{name}</h3>
      <p className="text-st-magenta text-sm mb-3">{role}</p>
      <div className="mb-4">
        {specialties.map((specialty, index) => (
          <span key={index} className="inline-block bg-st-light-grey text-st-dark-grey text-xs px-2 py-1 rounded-full mr-1 mb-1">
            {specialty}
          </span>
        ))}
      </div>
      <p className="text-gray-600 text-sm mb-4">Experience: {experience}</p>
      <Link href={`/clinicians/${slugify(name)}`} passHref>
        <Button variant="turquoise" size="sm">View Profile</Button>
      </Link>
    </Card>
  );
};

export default TeamMemberCard;


